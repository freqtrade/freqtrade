import random, time
from threading import Thread
import os.path

from execution.config import Config


class Back_Test_Market_Data_Worker_Thread(Thread):
    is_thread_stopped = False
    execution_id = None

    def __init__(self, execution_id):
        super(Back_Test_Market_Data_Worker_Thread, self).__init__()
        self.execution_id = execution_id

    def stop(self):
        self.is_thread_stopped = True

    def run(self):
        is_trigger_started = False
        file_name = Config.BACKTEST_DOWNLOAD_DATA_DIRECTORY + Config.COIN + "_" + Config.BACKTEST_TIMEFRAME_READABLE + "_" + \
                    Config.MONTH_LIST[Config.BACKTEST_MONTH_INDEX] + '_' + str(
            Config.BACKTEST_YEAR) + Config.CSV_FORMAT
        print("Back_Test_Market_Data_Worker_Thread: file_name=" + str(file_name))

        if os.path.isfile(file_name):
            file = open(file_name, 'r')
            lines = file.readlines()
            index = 0
            if Config.DEBUG_LOG_ENABLED:
                print("Back_Test_Market_Data_Worker_Thread: lines.size=" + str(len(lines)))

            for line in lines:
                array = line.split(",")

                if self.is_thread_stopped:
                    break

                line_time_stamp = int(array[0])
                if not is_trigger_started and line_time_stamp >= Config.BACKTEST_BUY_SIGNAL_TIMESTAMP:
                    is_trigger_started = True
                else:
                    if Config.DEBUG_LOG_ENABLED:
                        print(
                            "Back_Test_Market_Data_Worker_Thread: waiting for SIGNAL_TIMESTAMP to arrive...  BACKTEST_BUY_SIGNAL_TIMESTAMP=" + str(
                                Config.BACKTEST_BUY_SIGNAL_TIMESTAMP) +", BACKTEST_SELL_SIGNAL_TIMESTAMP="+ str(Config.BACKTEST_SELL_SIGNAL_TIMESTAMP) + ", line_time_stamp=" + str(line_time_stamp))

                if is_trigger_started:
                    index += 1

                    if Config.DEBUG_LOG_ENABLED:
                        print(
                            "Back_Test_Market_Data_Worker_Thread: PROGRESS="
                            + str(round(float((index * 100) / len(lines)), 2)) + " %"
                            + ", execution_id=" + self.execution_id
                            + ", coin=" + Config.COIN)

                    price_string = str(array[1])

                    Config.bus.emit(Config.EVENT_BUS_BACKTEST_MARKET_DATA_KEY, price_string)
                    time.sleep(Config.BACKTEST_THROTTLE_SECOND)

                    if Config.BACKTEST_SELL_SIGNAL_TIMESTAMP is not None and line_time_stamp >= Config.BACKTEST_SELL_SIGNAL_TIMESTAMP:
                        Config.bus.emit(Config.EVENT_BUS_BACKTEST_SELL_SIGNAL_KEY, price_string)
                        self.stop()

            file.close()
        else:
            print("Error: file_name does not exist. file_name=" + file_name)
