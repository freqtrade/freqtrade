from execution.notifier import Notifier, get_d_up_price
import requests
import os
from execution.config import Config
from execution._429_file_util import delete_429_file, write_to_429_file
from binance.enums import *
from execution.keys import Keys


class NotifierV(Notifier):
    def send_romeo_message_v(self, action, coin_amount, entry_price,
                           d_up_crossed_counter, execution_id,
                           profit=None, duration=None, romeo_exit_price_string=None,open_long_percentage=0,close_long_percentage=0,quantity_coin=0,current_price=0):
        print("Notifier: send_romeo_message: action=" + str(action))
        text = self.BOLD + "Action: " + self.BOLD + self.BOLD + action + self.BOLD + self.NL \
               + self.BOLD + "Machine: " + self.BOLD + str(self.machine_name) + self.NL \
               + self.BOLD + "Version: " + self.BOLD + Config.VERSION + self.NL \
               + self.BOLD + "Execution ID: " + self.BOLD + str(execution_id) + self.NL \
               + self.BOLD + "Brain: " + self.BOLD + Config.BRAIN.replace("_", " ") + self.NL \
               + self.BOLD + "Test mode: " + self.BOLD + str(self.is_test_mode) + ", Bnc-test-net: " + str(Config.BINANCE_TESTNET_MODE) + self.NL \
               + self.BOLD + "Entry price: " + self.BOLD + str(entry_price) + " USD"+self.NL \
               + self.BOLD + "Current price: " + self.BOLD + str(current_price) + " USD"+ self.NL \
               + self.BOLD + "D_UP_NOISE: " + self.BOLD + str(Config.ROMEO_D_UP_PERCENTAGE) + "% (" + str(
            get_d_up_price(entry_price)) + " USD)" + self.NL \
               + self.BOLD + "D_UP_NOISE crossed counter: " + self.BOLD + str(d_up_crossed_counter) + self.NL \
               + self.BOLD + "OPEN LONG PERCENTAGE: " + self.BOLD + str(open_long_percentage*100) + "%" + self.NL \
               + self.BOLD + "QUANTITY OPENED: " + self.BOLD + str(round(open_long_percentage * coin_amount)) + self.NL \
               + self.BOLD + "CLOSE LONG PERCENTAGE: " + self.BOLD + str(close_long_percentage*100) + "%" + self.NL \
               + self.BOLD + "QUANTITY CLOSED: " + self.BOLD + str(round(close_long_percentage * coin_amount)) + self.NL \
               + self.BOLD + "QUANTITY COIN: " + self.BOLD + str(quantity_coin) + self.NL \
               + self.BOLD + "TIMER_VALUE: " + self.BOLD + str(Config.TARGET_TIMER_VALUE) + " second(s)" +self.NL \
               + self.BOLD + "D_UP MAX: " + self.BOLD + str(Config.ROMEO_D_UP_MAX) + self.NL \
               + self.BOLD + "Duration: " + self.BOLD + str(duration) + self.NL \
               + self.BOLD + "Profit: " + self.BOLD + str(profit) + self.NL \
               + self.BOLD + "ExitPriceType: " + self.BOLD + str(romeo_exit_price_string).replace("_", " ") + self.NL \
               + (self.BOLD + "Position: " + self.BOLD + str(coin_amount) + " " + Config.COIN + " (" + str(
            get_binance_position_usd_value()) + " USD)")
        self.post_request(text, True)

    def get_telegram_bot_api_token(self):
        if self.is_test_mode:
            return Keys.NOTIFIER_TELEGRAM_BOT_API_TOKEN_ROMEO_V
        else:
            return Keys.NOTIFIER_TELEGRAM_BOT_API_TOKEN_ROMEO_V

    def get_telegram_channel_id(self):
        if self.is_test_mode:
            return Keys.NOTIFIER_TELEGRAM_CHANNEL_ID_ROMEO_V
        else:
            return Keys.NOTIFIER_TELEGRAM_CHANNEL_ID_ROMEO_V