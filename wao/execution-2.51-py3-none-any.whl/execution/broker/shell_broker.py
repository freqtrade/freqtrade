from execution.broker.broker import Broker


class Shell_Broker(Broker):
    # Example 0.271 LTC
    initial_position_coin_amount = 0.27
    partitioned_position_coin_amount = 0.12
    price_precision = 0

    def open_long(self, stop_order_price, dup_counter, force_market_order=False):
        pass

    def close_long(self, limit_order_price, force_market_order=False, force_refresh_coin_amount=False):
        pass
    
    def open_short(self, limit_order_price, dup_counter, force_market_order=False):
        pass

    def close_short(self, stop_order_price, force_market_order=False, force_refresh_coin_amount=False):
        pass

    def get_current_price(self):
        return 32

    def get_current_ask_price(self):
        return 33

    def get_current_bid_price(self):
        return 31

    def get_account_balance_usdt(self):
        return 100

    def get_all_open_positions(self):
        pass

    def get_all_open_positions_by_coin(self):
        pass
    
    def close_all_open_positions(self):
        pass

    def cancel_all_scheduled_positions(self):
        pass

    def cancel_all_scheduled_positions_by_coin(self):
        pass

    def get_scheduled_buy_order_list_count_by_coin(self):
        return 0

    def get_scheduled_sell_order_list_count_by_coin(self):
        return 0

    def get_recent_trade_history_list_by_coin(self):
        return []

    def get_remaining_account_balance_usdt(self):
        """
        TODO -- get remaining account balance after long positions are opened
        """
        return 1000
