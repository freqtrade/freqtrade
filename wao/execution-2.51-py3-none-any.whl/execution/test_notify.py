from execution.config import Config
from execution.notifier import Notifier
from execution.romeo_util import *

notifier = Notifier(True)
# notifier.send_broker_message("TEST BINANCE_ORDER:  ", 2, 7.3, "{}", 4)
notifier.send_romeo_message(
    "ROMEO_START : OL,OS,  Lvg : " + str(
        Config.BINANCE_LEVERAGE_VALUE) + ",  Acc: " + str(23),
    2, 7.3, 1, "test-execution-id", romeo_exit_price_string="PT")
