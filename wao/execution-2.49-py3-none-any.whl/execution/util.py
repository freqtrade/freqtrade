import time, datetime
from execution.config import Config
import os
from execution.romeo import Romeo


def is_execution_state_open():
    return not os.path.isfile(Config.BACKTEST_EXECUTION_FINISHED_FILE_PATH)


def clear_execution_state():
    print("clear_execution_state")
    _delete_file(Config.BACKTEST_EXECUTION_FINISHED_FILE_PATH)


def clear_cumulative_value():
    # delete cumulative file
    _delete_file(Config.CUMULATIVE_PROFIT_FILE_PATH)
    _delete_file(Config.CUMULATIVE_PROFIT_BINANCE_FILE_PATH)


def _delete_file(file_name):
    if os.path.isfile(file_name):
        os.remove(file_name)


def perform_back_test_sell(date_time):
    if Config.IS_SS_ENABLED:
        date = str(date_time).replace(" ", ", ")
        Config.BACKTEST_SELL_SIGNAL_TIMESTAMP = __get_unix_timestamp(date.split("+", 1)[0])
        print("perform_back_test_sell: BACKTEST_SELL_SIGNAL_TIMESTAMP=" + str(Config.BACKTEST_SELL_SIGNAL_TIMESTAMP))


def perform_back_test_buy(date_time, coin, brain, time_out_hours, dup):
    Config.COIN = coin
    Config.BRAIN = brain
    Config.ROMEO_SS_TIMEOUT_HOURS = time_out_hours
    Config.ROMEO_D_UP_PERCENTAGE = dup
    date = str(date_time).replace(" ", ", ")
    Config.BACKTEST_BUY_SIGNAL_TIMESTAMP = __get_unix_timestamp(date.split("+", 1)[0])
    Config.BACKTEST_MONTH_INDEX = __get_month_from_timestamp()
    Config.BACKTEST_YEAR = __get_year_from_timestamp()
    print("perform_back_test_buy: Config.BACKTEST_BUY_SIGNAL_TIMESTAMP = " + str(
        Config.BACKTEST_BUY_SIGNAL_TIMESTAMP) + " Config.BACKTEST_MONTH_INDEX = " + str(
        Config.BACKTEST_MONTH_INDEX) + " Config.COIN = " + str(
        Config.COIN) + " Config.BRAIN = " + str(
        Config.BRAIN) + " Config.ROMEO_D_UP_PERCENTAGE = " + str(
        Config.ROMEO_D_UP_PERCENTAGE) + " Config.ROMEO_D_UP_MAX = " + str(
        Config.ROMEO_D_UP_MAX))

    romeo = Romeo.instance(True, True)
    romeo.start()


def __get_month_from_timestamp():
    date = str(time.strftime("%Y-%m-%d", time.localtime(Config.BACKTEST_BUY_SIGNAL_TIMESTAMP)))
    date = datetime.datetime.strptime(str(date), "%Y-%m-%d")
    return date.month - 1 if date.month <= 12 else 0


def __get_year_from_timestamp():
    date = str(time.strftime("%Y-%m-%d", time.localtime(Config.BACKTEST_BUY_SIGNAL_TIMESTAMP)))
    date = datetime.datetime.strptime(str(date), "%Y-%m-%d")
    return date.year


def __get_unix_timestamp(date):
    date_time = datetime.datetime.strptime(date,
                                           "%Y-%m-%d, %H:%M:%S")
    unix_time = datetime.datetime.timestamp(date_time)
    return int(unix_time)
