import smtplib
from execution.keys import Keys
from execution.config import Config


class Email_Notifier:
    def __init__(self):
        self.server = smtplib.SMTP('smtp.gmail.com', 587)
        self.server.ehlo()
        self.server.starttls()
        self.server.login(Keys.NOTIFIER_SENDER_EMAIL_ADDRESS, Keys.NOTIFIER_SENDER_EMAIL_PASSWORD)

    def send_email(self, action, coin_amount, usdt_amount):
        print("Notifier: send_email: action="+str(action))
        subject = action + " - " + Config.COIN
        text = action + ": " + str(coin_amount) + " " + Config.COIN + " (" + str(usdt_amount) + " USD)"
        msg = 'Subject: {}\n\n{}'.format(subject, text)
        self.server.sendmail(Keys.NOTIFIER_SENDER_EMAIL_ADDRESS, Keys.NOTIFIER_RECEIVER_EMAIL_ADDRESS, msg)
        self.server.quit()
