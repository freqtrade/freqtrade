from execution.broker.binance_future_broker import Binance_Future_Broker
from execution.broker.binance_spot_broker import Binance_Spot_Broker
from execution.broker.shell_broker import Shell_Broker
from execution.cumulative_profit_file_util import append_to_cumulative_profit_file, set_initial_account_balance_binance, \
    get_initial_account_balance_binance
from execution.market_data_worker_thread.back_test_market_data_worker_thread import Back_Test_Market_Data_Worker_Thread
from execution.market_data_worker_thread.back_test_v3_live_market_data_worker_thread import \
    Back_Test_V3_Live_Market_Data_Worker_Thread
from execution.market_data_worker_thread.binance_market_data_worker_thread import Binance_Market_Data_Worker_Thread
from execution.notifier import Notifier
from execution.romeo_util import *
from time import time


class RomeoState(Enum):
    BELOW_ENTRY = 1
    ABOVE_ENTRY_BELOW_D_UP = 2
    ABOVE_D_UP_BELOW_PT = 3
    ABOVE_PT = 4


class RomeoExitPriceType(Enum):
    SS = 1
    PT = 2
    ENTRY_PRICE = 3


class ProfitExitType(Enum):
    ABOVE_DUP = 1
    ABOVE_ENTRY_BELOW_D_UP = 2
    ENTRY_PRICE_OR_BELOW = 3


def _perform_romeo(price):
    romeo = Romeo.instance(Romeo.is_test_mode)
    romeo.current_price = price

    romeo.init_broker()
    if Config.IS_SCHEDULE_ORDER:
        romeo.init_scheduled_order_count()

    if Config.DEBUG_LOG_ENABLED:
        print("Romeo: _perform_romeo: price=" + str(price) + " entry_price=" + str(
            romeo.entry_price) + " is_started=" + str(romeo.is_started) + " d_up_crossed_counter=" + str(
            romeo.d_up_crossed_counter) + ", execution_id="+str(romeo.execution_id) + ", is_long_open="+str(romeo.is_long_open))

    if romeo.is_started:

        if Config.DEBUG_LOG_ENABLED:
            print("Romeo: _perform_romeo: d_up=" + str(romeo.d_up_price) + " pt=" + str(
                romeo.pt_price) + " coin=" + Config.COIN + " brain=" + Config.BRAIN)

        romeo.prev_state = romeo.current_state
        romeo.current_state = romeo.get_current_state()

        if Config.DEBUG_LOG_ENABLED:
            print("Romeo: _perform_romeo: prev_state=" + str(romeo.prev_state) + " current_state=" + str(
                romeo.current_state))

        # Error Cases [START] - Health Monitor
        if not romeo.is_long_open and romeo.current_price > romeo.d_up_price * (1 + Config.HEALTH_MONITOR_ABOVE_DUP_PERCENTAGE):
            print(
                "Romeo: _perform_romeo: Error:  [not is_long_open AND current_price is above dup]. dup_price=" + str(
                    romeo.d_up_price) +
                " current_price=" + str(romeo.current_price))
            romeo.is_started = False

        if romeo.d_up_crossed_counter > Config.ROMEO_D_UP_MAX:
            print("Romeo: _perform_romeo: Error - dup counter is above dup max counter: "
                  "d_up_crossed_counter= " + str(romeo.d_up_crossed_counter) + "D_UP_MAX=" + str(
                Config.ROMEO_D_UP_MAX))
            romeo.is_started = False

        if romeo.current_price > romeo.d_up_price * (1 + Config.HEALTH_MONITOR_ABOVE_DUP_PERCENTAGE) and romeo.d_up_crossed_counter == 0:
            print( "Romeo: _perform_romeo: Error:  [current_price is above dup and romeo.d_up_crossed_counter == 0]")
            romeo.is_started = False

        open_long_positions = romeo.broker.get_all_open_positions_by_coin()
        entry_price_health_monitor_level = romeo.entry_price * (1 - Config.HEALTH_MONITOR_BELOW_ENTRY_PRICE_PERCENTAGE)
        if romeo.current_price < entry_price_health_monitor_level and romeo.is_long_open and open_long_positions:
            print("Romeo: _perform_romeo: Error: [ romeo.current_price < romeo.entry_price and romeo.is_long_open and open_long_positions]")
            romeo.is_started = False
        # Error Cases [END] - Health Monitor

        if not Config.IS_SCHEDULE_ORDER and not romeo.is_long_open \
                and (romeo.prev_state == RomeoState.BELOW_ENTRY
                     or romeo.prev_state == RomeoState.ABOVE_ENTRY_BELOW_D_UP) \
                and (romeo.current_state == RomeoState.ABOVE_D_UP_BELOW_PT
                     or romeo.current_state == RomeoState.ABOVE_PT):  # yellow - d_up crossed
            romeo.on_dup_crossed_upwards_callback()

        if not Config.IS_SCHEDULE_ORDER and romeo.prev_state == RomeoState.ABOVE_D_UP_BELOW_PT \
                and romeo.current_state == RomeoState.ABOVE_PT \
                and not Config.IS_SS_ENABLED:  # green - PT reached
            romeo.perform_sell_signal(RomeoExitPriceType.PT)

        if not Config.IS_SCHEDULE_ORDER and romeo.is_long_open \
                and romeo.d_up_crossed_counter > 0 \
                and (romeo.prev_state == RomeoState.ABOVE_PT
                     or romeo.prev_state == RomeoState.ABOVE_D_UP_BELOW_PT
                     or romeo.prev_state == RomeoState.ABOVE_ENTRY_BELOW_D_UP) \
                and romeo.current_state == RomeoState.BELOW_ENTRY:  # purple - entry_price crossed downwards
            romeo.on_entry_crossed_downwards_callback()

        if Config.IS_SS_ENABLED and get_duration_minutes(romeo.start_timestamp) > (
                Config.ROMEO_SS_TIMEOUT_HOURS * 60):
            print("Romeo: _perform_romeo: warning: timeout: sending ss")
            romeo.perform_sell_signal(RomeoExitPriceType.SS, is_timed_out=True)

        if romeo.is_started and Config.IS_SCHEDULE_ORDER:
            # give delay: binance_broker.get_scheduled_order returns Max retries exceeded error
            simulation_delay = time() - romeo.simulate_limit_order_timestamp

            print("Romeo: _perform_romeo: simulation_delay=" + str(
                simulation_delay) + ", SIMULATE_LIMIT_ORDER_CALLBACK_DELAY_SEC=" + str(
                Config.SIMULATE_LIMIT_ORDER_CALLBACK_DELAY_SEC))

            if simulation_delay > Config.SIMULATE_LIMIT_ORDER_CALLBACK_DELAY_SEC:
                romeo.simulate_limit_order_callback()
                romeo.simulate_limit_order_timestamp = time()


class Romeo:
    execution_id = None
    # counts when price first crosses entry then dup
    d_up_crossed_counter = 0
    is_started = False
    prev_state = None
    current_state = None
    _instance = None
    broker = None
    notifier = None
    is_test_mode = False
    is_long_open = False
    start_timestamp = 0.0
    simulate_limit_order_timestamp = 0.0
    notify_message_counter = 0
    back_test_market_data_worker_thread = None
    binance_market_data_worker = None
    back_test_sell_signal_exit_price = 0.0
    profit_loss_percentage = 0.0
    current_price = 0.0
    starting_account_balance_usd = 0.0
    scheduled_buy_order_prev_count = None
    scheduled_sell_order_prev_count = None

    entry_price = None
    d_up_price = None
    pt_price = None

    @classmethod
    def instance(cls, is_test_mode, force_new_instance=False):
        if cls._instance is None or force_new_instance:
            print('Romeo: new instance ====== system.version=' + Config.VERSION +
                  ", ROMEO_SS_TIMEOUT_HOURS=" + str(Config.ROMEO_SS_TIMEOUT_HOURS)
                  + ", IS_SS_ENABLED=" + str(Config.IS_SS_ENABLED) + ", D_UP=" + str(
                      Config.ROMEO_D_UP_PERCENTAGE) + ", D_UP_MAX=" + str(Config.ROMEO_D_UP_MAX)
                  + ", IS_SCHEDULE_ORDER=" + str(Config.IS_SCHEDULE_ORDER))
            cls._instance = cls.__new__(cls)
            cls._instance.execution_id = get_execution_id()
            cls._instance.notifier = Notifier(is_test_mode)
            cls._instance.back_test_market_data_worker_thread = Back_Test_V3_Live_Market_Data_Worker_Thread(
                cls._instance.execution_id) if Config.IS_BACKTEST_V3_ENABLED else \
                Back_Test_Market_Data_Worker_Thread(cls._instance.execution_id)
            cls._instance.binance_market_data_worker = Binance_Market_Data_Worker_Thread()
            Romeo.is_test_mode = is_test_mode
            cls._instance.init_broker()

        return cls._instance

    def start(self):
        print("Romeo: START ")

        if not self.is_account_balance_sufficient(get_binance_position_usd_value(1)):
            return

        self.starting_account_balance_usd = self.broker.get_account_balance_usdt()
        set_initial_account_balance_binance(self.starting_account_balance_usd)

        self.d_up_crossed_counter = 0
        self.start_timestamp = time()

        # Set Romeo Parameters
        self.entry_price = self.broker.get_current_price()
        self.d_up_price = self.entry_price + (self.entry_price * Config.ROMEO_D_UP_PERCENTAGE / 100.0)
        self.pt_price = self.entry_price + (self.entry_price * Config.ROMEO_PT_PERCENTAGE / 100.0)

        # Round Romeo Parameters
        self.entry_price = round(self.entry_price, self.broker.price_precision)
        self.d_up_price = round(self.d_up_price, self.broker.price_precision)
        self.pt_price = round(self.pt_price, self.broker.price_precision)

        print("Romeo: START: setting params: " + " entry_price=" + str(self.entry_price))

        if Config.IS_SCHEDULE_ORDER:
            self.simulate_limit_order_timestamp = time()

            # schedule d_up
            print("Romeo: START: SCHEDULE OL AT D_UP")
            self.broker.open_long(self.d_up_price, self.d_up_crossed_counter)
            self.scheduled_buy_order_prev_count = 1

            # schedule pt
            if not Config.IS_SS_ENABLED:
                print("Romeo: START: SCHEDULE CL AT PT")
                self.broker.close_long(self.pt_price)
                self.scheduled_sell_order_prev_count = 1

        self.is_started = True

        self._perform_notify(
            "ROMEO_START: Lvg: " + str(
                Config.BINANCE_LEVERAGE_VALUE) + ", Acc: " + str(
                self.starting_account_balance_usd) + " USD, Brh: " + get_active_branch_name(), 0.0,
            force_notify=True)

        self.subscribe_market_data()

    def is_account_balance_sufficient(self, position_usd_value):
        if not self.is_test_mode:
            account_balance_usd = self.broker.get_remaining_account_balance_usdt()
            position_usd = position_usd_value / Config.BINANCE_LEVERAGE_VALUE
            is_account_balance_sufficient = account_balance_usd > position_usd
            if not is_account_balance_sufficient:
                print("Romeo: Error: account balance too low: account_balance=" + str(
                    account_balance_usd) + ", position_usd=" + str(position_usd) + ", is_account_balance_sufficient=False")
            return is_account_balance_sufficient
        else:
            return True

    def perform_sell_signal(self, romeo_exit_price, is_timed_out=False, is_dup_max_reached=False):
        print("Romeo: perform_sell_signal: romeo_exit_price=" + str(romeo_exit_price.name) + ", is_timed_out=" + str(
            is_timed_out) + ", is_dup_max_reached=" + str(
            is_dup_max_reached), ", self.is_started=" + str(self.is_started))

        if self.is_started:
            self.is_started = False
            
        ss_notify_string = "ROMEO: SELL:" + str(romeo_exit_price.name) + ": FINISH"
        if is_timed_out or is_dup_max_reached:
            Config.bus.emit(Config.EVENT_BUS_EXECUTION_SELF_COMPLETE, Config.COIN)
            ss_notify_string += (" is_timed_out=" + str(is_timed_out) + ", is_dup_max_reached=" + str(is_dup_max_reached))
        self.notify(ss_notify_string)
        self.finish(romeo_exit_price)

    def finish(self, romeo_exit_price):
        print("Romeo: FINISH :" + romeo_exit_price.name + ", is_long_open=" + str(self.is_long_open))
        romeo_exit_price_string = romeo_exit_price.name + (", is_long_open=" + str(self.is_long_open))
        profit_loss_string = self.get_profit_loss_string(romeo_exit_price)
        self.notify("ROMEO_FINISH: CL",
                    duration=get_duration_string(self.start_timestamp),
                    profit=profit_loss_string,
                    force_notify=True, romeo_exit_price_string=romeo_exit_price_string)

        if Config.IS_SCHEDULE_ORDER:
            self.broker.cancel_all_scheduled_positions_by_coin()

        # CL
        if self.is_long_open:
            self.broker.close_long(0, force_market_order=True)
            self.is_long_open = False

        self.unsubscribe_market_data()

        if Config.IS_BACKTEST:
            write_backtest_execution_finished_file()

        if Config.IS_ROMEO_MESSAGE_TO_GOOGLE_SHEET_ENABLED:
            write_romeo_message_to_google_sheet(str(self.execution_id) + "-" + str(self.notify_message_counter),
                                                Config.COIN,
                                                self.entry_price, self.d_up_price, Config.ROMEO_D_UP_MAX,
                                                self.d_up_crossed_counter, exit_price_type=romeo_exit_price_string,
                                                profit=profit_loss_string)

        if Config.IS_PERFORMANCE_MONITOR_ENABLED:
            self.performance_monitor()

    def performance_monitor(self):
        theoretical_cumulative_profit_per_coin = append_to_cumulative_profit_file(Config.CUMULATIVE_PROFIT_FILE_PATH,
                                                                                  self.profit_loss_percentage)

        theoretical_cumulative_profit_loss_percentage_without_leverage = theoretical_cumulative_profit_per_coin / Config.BINANCE_LEVERAGE_VALUE
        print("Romeo: performance_monitor: theoretical_cumulative_profit_per_coin=" + str(
            theoretical_cumulative_profit_per_coin) + "%" + ", theoretical_cumulative_profit_loss_percentage_without_leverage=" + str(
            theoretical_cumulative_profit_loss_percentage_without_leverage) + "%")

        if theoretical_cumulative_profit_loss_percentage_without_leverage > Config.PERFORMANCE_MONITOR_MAX_LOSS_PERCENTAGE_ACCOUNT:
            print("Performance monitor Error: MAX LOSS TRIGGERED! Pure Loss=" + str(
                theoretical_cumulative_profit_loss_percentage_without_leverage) + "%")

    def subscribe_market_data(self):
        print("Romeo: subscribe_market_data")
        if Config.IS_BACKTEST:
            self.back_test_market_data_worker_thread.start()
        else:
            self.binance_market_data_worker.start()

    def unsubscribe_market_data(self):
        print("Romeo: unsubscribe_market_data")
        if Config.IS_BACKTEST:
            self.back_test_market_data_worker_thread.stop()
        else:
            self.binance_market_data_worker.stop()

    # This method is called from limit order callbacks as well
    # This is what romeo does when on_dup_crossed_upwards:
    def on_dup_crossed_upwards_callback(self):
        print("Romeo: on_dup_crossed_upwards_callback: is_long_open="+str(self.is_long_open) + ", d_up_crossed_counter="+str(self.d_up_crossed_counter))

        if Config.IS_SCHEDULE_ORDER:
            self.d_up_crossed_counter += 1
            # schedule CL at entry
            print("Romeo: on_dup_crossed_upwards_callback: SCHEDULE CL AT ENTRY")
            self.broker.close_long(self.entry_price)
            self.scheduled_sell_order_prev_count = 1
        elif not self.is_long_open:
            self.broker.open_long(self.d_up_price, self.d_up_crossed_counter)
            self.is_long_open = True
            self.d_up_crossed_counter += 1

        self.notify("ROMEO: UPWARDS: Price Crossing D_UP: OL")

    # This method is called from limit order callbacks as well
    # This is what romeo does when on_entry_crossed_downwards:
    def on_entry_crossed_downwards_callback(self):
        print("Romeo: on_entry_crossed_downwards_callback: is_long_open="+str(self.is_long_open) + ", d_up_crossed_counter="+str(self.d_up_crossed_counter))

        if self.d_up_crossed_counter == Config.ROMEO_D_UP_MAX:
            self.perform_sell_signal(RomeoExitPriceType.ENTRY_PRICE, is_dup_max_reached=True)
        else:
            self.notify("ROMEO: DOWNWARDS: Price Crossing ENTRY_PRICE: CL (LOSS)")

            if Config.IS_SCHEDULE_ORDER:
                if not self.is_account_balance_sufficient(get_binance_position_usd_value(self.d_up_crossed_counter)):
                    return
                # schedule OL at d_up
                print("Romeo: on_entry_crossed_downwards_callback: SCHEDULE OL AT D_UP")
                self.broker.open_long(self.d_up_price, self.d_up_crossed_counter)
                self.scheduled_buy_order_prev_count = 1
            else:
                self.broker.close_long(self.entry_price)

            self.is_long_open = False

    def simulate_limit_order_callback(self):
        scheduled_buy_order_current_count = self.broker.get_scheduled_buy_order_list_count_by_coin()
        scheduled_sell_order_current_count = self.broker.get_scheduled_sell_order_list_count_by_coin()

        print("Romeo: simulate_limit_order_callback:  self.scheduled_buy_order_prev_count=" + str(
            self.scheduled_buy_order_prev_count) + ", scheduled_buy_order_current_count=" + str(
             scheduled_buy_order_current_count) +
              ", scheduled_sell_order_prev_count=" + str(self.scheduled_sell_order_prev_count) +
              ", scheduled_sell_order_current_count=" + str(scheduled_sell_order_current_count))

        if scheduled_buy_order_current_count < self.scheduled_buy_order_prev_count and is_near(
                self.current_price, self.d_up_price):
            print("Romeo: simulate_limit_order_callback: on_dup_crossed_upwards_callbacks")
            self.is_long_open = True
            self.on_dup_crossed_upwards_callback()
        elif scheduled_sell_order_current_count < self.scheduled_sell_order_prev_count and is_near(
                self.current_price, self.entry_price):
            self.is_long_open = False
            print("Romeo: simulate_limit_order_callback: on_entry_crossed_downwards_callback")
            self.on_entry_crossed_downwards_callback()

        self.scheduled_buy_order_prev_count = scheduled_buy_order_current_count
        self.scheduled_sell_order_prev_count = scheduled_sell_order_current_count

    def init_broker(self):
        if self.broker is None:
            if Config.IS_SHELL_BROKER_ENABLED:
                self.broker = Shell_Broker(self.notifier)
            else:
                if Config.IS_BINANCE_FUTURE_MODE:
                    self.broker = Binance_Future_Broker(self.notifier)
                else:
                    self.broker = Binance_Spot_Broker(self.notifier)

    def init_scheduled_order_count(self):
        if self.scheduled_buy_order_prev_count is None:
            self.scheduled_buy_order_prev_count = self.broker.get_scheduled_buy_order_list_count_by_coin()
        if self.scheduled_sell_order_prev_count is None:
            self.scheduled_sell_order_prev_count = self.broker.get_scheduled_sell_order_list_count_by_coin()

    def get_profit_loss_string(self, romeo_exit_price):
        ss_exit_price_string = ""
        if romeo_exit_price == RomeoExitPriceType.SS:

            ss_exit_price = self.back_test_sell_signal_exit_price if Config.IS_BACKTEST else self.broker.get_current_price()
            ss_exit_price_string = ", SSExitPrice: " + str(ss_exit_price) + " USD"

            self.profit_loss_percentage = self._get_ss_profit_loss_percentage(ss_exit_price)
        elif romeo_exit_price == RomeoExitPriceType.PT:

            previous_cumulative_dup_percentage = get_partitioned_previous_cumulative_dup_loss_percentage(self.d_up_crossed_counter,
                                                                                        ProfitExitType.ABOVE_DUP) \
                if Config.IS_DUP_PARTITION_ENABLED else self.d_up_crossed_counter * Config.ROMEO_D_UP_PERCENTAGE

            self.profit_loss_percentage = Config.ROMEO_PT_PERCENTAGE - previous_cumulative_dup_percentage

        elif romeo_exit_price == RomeoExitPriceType.ENTRY_PRICE:

            previous_cumulative_dup_percentage = get_partitioned_previous_cumulative_dup_loss_percentage(self.d_up_crossed_counter,
                                                                                        ProfitExitType.ENTRY_PRICE_OR_BELOW) \
                if Config.IS_DUP_PARTITION_ENABLED else self.d_up_crossed_counter * Config.ROMEO_D_UP_PERCENTAGE

            self.profit_loss_percentage = - previous_cumulative_dup_percentage

        self.profit_loss_percentage *= Config.BINANCE_LEVERAGE_VALUE
        self.profit_loss_percentage = round(self.profit_loss_percentage, 2)

        current_account_balance = self.broker.get_account_balance_usdt()
        initial_account_balance = get_initial_account_balance_binance()
        profit_loss_percentage_binance = ((
                                                  current_account_balance - initial_account_balance) * 100.0) / initial_account_balance
        profit_loss_percentage_binance = round(profit_loss_percentage_binance, 2)

        new_cumulative_profit_binance = append_to_cumulative_profit_file(Config.CUMULATIVE_PROFIT_BINANCE_FILE_PATH,
                                                                         profit_loss_percentage_binance)

        return str(self.profit_loss_percentage) + " %" + \
               ss_exit_price_string + ", Acc: " + str(current_account_balance) + " USD, Bnc-Cum-Prf: " + str(
            new_cumulative_profit_binance) + " %"

    def _get_ss_profit_loss_percentage(self, ss_exit_price):
        ss_percentage = ((ss_exit_price - self.d_up_price) / self.d_up_price) * 100.0

        if Config.IS_DUP_PARTITION_ENABLED:
            ss_percentage *= Config.DUP_PARTITION[
                self.d_up_crossed_counter]  # the Nth partition was the position size
            
        ss_profit_loss_percentage = 0.0

        if ss_exit_price >= self.d_up_price:

            previous_cumulative_dup_percentage = get_partitioned_previous_cumulative_dup_loss_percentage(self.d_up_crossed_counter,
                                                                                        ProfitExitType.ABOVE_DUP) \
                if Config.IS_DUP_PARTITION_ENABLED else (self.d_up_crossed_counter - 1) * Config.ROMEO_D_UP_PERCENTAGE

            ss_profit_loss_percentage = ss_percentage - previous_cumulative_dup_percentage

        elif self.entry_price < ss_exit_price < self.d_up_price:

            previous_cumulative_dup_percentage = get_partitioned_previous_cumulative_dup_loss_percentage(self.d_up_crossed_counter,
                                                                                        ProfitExitType.ABOVE_ENTRY_BELOW_D_UP) \
                if Config.IS_DUP_PARTITION_ENABLED else (self.d_up_crossed_counter - 1) * Config.ROMEO_D_UP_PERCENTAGE

            if self.is_long_open:
                ss_profit_loss_percentage = ss_percentage - previous_cumulative_dup_percentage
            else:
                ss_profit_loss_percentage = 0  # if ss comes before first reach of dup

        elif ss_exit_price <= self.entry_price:

            previous_cumulative_dup_percentage = get_partitioned_previous_cumulative_dup_loss_percentage(self.d_up_crossed_counter,
                                                                                        ProfitExitType.ENTRY_PRICE_OR_BELOW) \
                if Config.IS_DUP_PARTITION_ENABLED else self.d_up_crossed_counter * Config.ROMEO_D_UP_PERCENTAGE

            if self.d_up_crossed_counter > 0:
                ss_profit_loss_percentage = - previous_cumulative_dup_percentage
            else:
                ss_profit_loss_percentage = 0

        print("Romeo: _get_ss_profit_loss_percentage: ss_percentage="+str(ss_percentage) + ", dup_counter="+str(
            self.d_up_crossed_counter) +  ", ss_profit_loss_percentage="+str(ss_profit_loss_percentage))

        return ss_profit_loss_percentage

    @Config.bus.on(Config.EVENT_BUS_MARKET_DATA_KEY)
    def on_market_data(json_message_string):
        # if Config.DEBUG_LOG_ENABLED:
        # print("on_market_data: "+ json_message_string)
        price = get_price(json_message_string)
        _perform_romeo(price)

    @Config.bus.on(Config.EVENT_BUS_BACKTEST_MARKET_DATA_KEY)
    def on_back_test_market_data(price):
        _perform_romeo(float(price))

    @Config.bus.on(Config.EVENT_BUS_BACKTEST_SELL_SIGNAL_KEY)
    def on_back_test_sell_signal(price):
        romeo = Romeo.instance(Romeo.is_test_mode)
        romeo.back_test_sell_signal_exit_price = float(price)
        romeo.perform_sell_signal(RomeoExitPriceType.SS)

    @Config.bus.on(Config.EVENT_BUS_BINANCE_RECONNECT)
    def on_binance_reconnect(message):
        romeo = Romeo.instance(Romeo.is_test_mode)
        romeo.unsubscribe_market_data()
        romeo.subscribe_market_data()

    def notify(self, action, duration=None, profit=None, force_notify=False, romeo_exit_price_string=None):
        if Config.ROMEO_VERBOSE_MODE or force_notify:
            self._perform_notify(action,
                                 self.broker.partitioned_position_coin_amount if Config.IS_DUP_PARTITION_ENABLED else self.broker.initial_position_coin_amount,
                                 duration=duration, profit=profit,
                                 force_notify=force_notify,
                                 romeo_exit_price_string=romeo_exit_price_string)

    def _perform_notify(self, action,
                        position_coin_amount,
                        duration=None, profit=None, force_notify=False, romeo_exit_price_string=None):
        if Config.ROMEO_VERBOSE_MODE or force_notify:
            self.notify_message_counter += 1
            self.notifier.send_romeo_message(action, position_coin_amount,
                                             self.entry_price,
                                             self.d_up_crossed_counter,
                                             str(self.execution_id) + "-" + str(self.notify_message_counter),
                                             duration=duration, profit=profit,
                                             romeo_exit_price_string=romeo_exit_price_string)

    def get_current_state(self):
        if self.entry_price < self.current_price < self.d_up_price:
            return RomeoState.ABOVE_ENTRY_BELOW_D_UP
        elif self.d_up_price < self.current_price < self.pt_price:
            return RomeoState.ABOVE_D_UP_BELOW_PT
        elif self.pt_price < self.current_price:
            return RomeoState.ABOVE_PT
        elif self.current_price < self.entry_price:
            return RomeoState.BELOW_ENTRY
        else:
            return self.prev_state
