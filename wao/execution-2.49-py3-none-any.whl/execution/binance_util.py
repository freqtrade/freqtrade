from execution.config import Config
from execution.keys import Keys
import datetime


def get_binance_api_key():
    if Config.BINANCE_TESTNET_MODE:
        return Keys.BINANCE_TESTNET_API_KEY
    else:
        return Keys.BINANCE_API_KEY


def get_binance_api_secret():
    if Config.BINANCE_TESTNET_MODE:
        return Keys.BINANCE_TESTNET_API_SECRET
    else:
        return Keys.BINANCE_API_SECRET


def get_timestamp_before_sec(sec):
    return int((datetime.datetime.now() - datetime.timedelta(seconds=sec)).timestamp() * 1000)


def get_binance_position_usd_value():
    return (3 if Config.IS_DUP_PARTITION_ENABLED else 1) * Config.BINANCE_POSITION_USD_VALUE


def get_position_coin_amount_partitioned(position_coin_amount, dup_counter):
    return Config.DUP_PARTITION[dup_counter+1] * position_coin_amount


def get_precised_position_coin_amount(raw_position_coin_amount, quantity_precision):
    position_coin_amount = round(raw_position_coin_amount, quantity_precision)
    if position_coin_amount == 0:
        position_coin_amount = (raw_position_coin_amount * 10 ** quantity_precision) + 1
        position_coin_amount = position_coin_amount / 10 ** quantity_precision
        position_coin_amount = round(position_coin_amount, quantity_precision)

        if position_coin_amount >= 1:
            usd_value = __convert_coin_to_usd(position_coin_amount)
            if usd_value > get_binance_position_usd_value():
                position_coin_amount = round(raw_position_coin_amount, 2)

    return position_coin_amount
