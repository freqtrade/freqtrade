from execution.romeo import Romeo


Romeo.instance(True).start()

# def start():
#     Romeo.instance()

# if __name__ == '__main__':
#     delay = 2  # in seconds
#     Timer(delay, start, []).start()

