
class BacktestSignal:

    def __init__(self, brain, coin, type, timeout_hours, dup, timestamp=None):
        self.brain = brain
        self.coin = coin
        self.type = type
        self.timeout_hours = timeout_hours
        self.dup = dup
        self.timestamp = timestamp

    def __str__(self):
        return f'(brain={self.brain}, coin={self.coin}, type={self.type}, timeout_hours={self.timeout_hours}, dup={self.dup}, timestamp={self.timestamp})\n'


class BacktestExecution:

    def __init__(self, buy_signal, sell_signal):
        self.buy_signal = buy_signal
        self.sell_signal = sell_signal

    def is_ready(self):
        return self.buy_signal is not None and self.sell_signal is not None

    def __str__(self):
        return f'(buy_signal={self.buy_signal}, sell_signal={self.sell_signal}\n'
