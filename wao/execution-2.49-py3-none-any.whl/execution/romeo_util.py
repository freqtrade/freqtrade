import csv
import os
import subprocess
from execution.config import Config
from execution.keys import Keys
from pathlib import Path
import gspread
from oauth2client.service_account import ServiceAccountCredentials
import datetime
from enum import Enum
from time import time
import time as time_orig


def write_backtest_execution_finished_file():
    file_name = Config.BACKTEST_EXECUTION_FINISHED_FILE_PATH
    with open(file_name, 'w') as file:
        file.write("")
    file.close()
    print("write_backtest_execution_finished_file: result=" + str(os.path.exists(file_name)))


def get_execution_id():
    return str(int(time())) + "-" + Config.COIN


def get_price(json_message_string):
    return _get_trade_stream_price(
        json_message_string) if Config.BINANCE_TRADE_STREAM_ENABLED else _get_candle_close_price(
        json_message_string)


def _get_trade_stream_price(json_message_string):
    json_obj = eval(json_message_string)
    return float(json_obj['p'])


def _get_candle_close_price(json_message_string):
    json_obj = eval(json_message_string)
    candle = json_obj['k']
    return float(candle['c'])


def _get_depth_price(json_message_string):
    json_obj = eval(json_message_string)
    asks = json_obj['a']
    bids = json_obj['b']
    ask = 0.0
    bid = 0.0
    price = 0.0
    if len(asks) > 0:
        ask = float(asks[0][0])
    if len(bids) > 0:
        bid = float(bids[0][0])

    price = (ask + bid) / 2.0

    if price == 0.0:
        print("Error: _get_depth_price is 0. json_message_string=" + json_message_string)
    return price


def get_active_branch_name():
    head_dir = Path("../.") / ".git" / "HEAD"
    with head_dir.open("r") as f:
        content = f.read().splitlines()

    for line in content:
        if line[0:4] == "ref:":
            return line.partition("refs/heads/")[2]


def is_near(price, level):
    percentage = 0.05  # 5 percent wiggle space
    return level * (1 - percentage) < price < level * (1 + percentage)


def __get_current_date():
    return time_orig.strftime('%b %d, %Y. %H:%M%p %Z')


def __create_romeo_message_csv_directory():
    print("create_directory:..." + Config._ROMEO_MESSAGE_CSV_FILE_DIRECTORY + "...")
    if not os.path.exists(Config._ROMEO_MESSAGE_CSV_FILE_DIRECTORY):
        os.mkdir(Config._ROMEO_MESSAGE_CSV_FILE_DIRECTORY)
        __write_romeo_message_csv_header()


def __write_romeo_message_csv_header():
    write_romeo_message_to_csv_row("execution_id", "coin", "entry_price", "d_up", "d_up_max",
                                   "d_up_crossed_counter", "exit_price_type", "profit", "ss_price", "bin_cum_profit",
                                   "date")


def write_romeo_message_to_csv_row(execution_id, coin, entry_price, d_up, d_up_max, d_up_crossed_counter,
                                   exit_price_type=None, profit=None,
                                   ss_price=None, bin_cum_profit=None, date_param=None):
    __create_romeo_message_csv_directory()
    print("write_romeo_message_to_csv_row:...")
    date = __get_current_date() if date_param is None else date_param
    if ss_price is None or bin_cum_profit is None:
        profit_arr = profit.split(",")
        ss_price = profit_arr[1].split(":")[1].split()[0] if "SSExitPrice" in profit_arr[1] else 0.0
        bin_cum_profit = profit_arr[-1].split(":")[1]
        profit = profit_arr[0].split(" ")[0]
    csvfile = open(Config._ROMEO_MESSAGE_CSV_FILE_DIRECTORY + "romeo_message" + Config.CSV_FORMAT,
                   'a', newline='')
    csv_writer = csv.writer(csvfile, delimiter=',')
    csv_writer.writerow((date, execution_id, coin, entry_price, d_up, d_up_max,
                         d_up_crossed_counter, exit_price_type, profit, ss_price, bin_cum_profit))
    csvfile.close()


def write_romeo_message_to_google_sheet(execution_id, coin, entry_price, d_up, d_up_max,
                                        d_up_crossed_counter, exit_price_type=None, profit=None,
                                        ss_price=None, bin_cum_profit=None):
    print("write_romeo_message_to_google_sheet:...")
    scopes = [
        'https://www.googleapis.com/auth/spreadsheets',
        'https://www.googleapis.com/auth/drive'
    ]
    credentials = ServiceAccountCredentials.from_json_keyfile_name(os.path.join(
                os.path.dirname(os.path.abspath(__file__)),
                'to_google_sheet.json'), scopes)
    file = gspread.authorize(credentials)
    sheet = file.open("romeo_messages")
    sheet = sheet.worksheet(Keys.WORKSHEET_TITLE.get(Config.BRAIN, "others"))
    date = __get_current_date()

    if ss_price is None or bin_cum_profit is None:
        profit_arr = profit.split(",")
        ss_price = profit_arr[1].split(":")[1].split()[0] if "SSExitPrice" in profit_arr[1] else 0.0
        bin_cum_profit = profit_arr[-1].split(":")[1]
        profit = profit_arr[0].split(" ")[0]

    list_of_romeo_messages = [date, Config.VERSION, execution_id, coin, entry_price, d_up, d_up_max,
                              d_up_crossed_counter, exit_price_type, profit,
                              ss_price, bin_cum_profit]
    sheet.append_row(list_of_romeo_messages)
    list_of_romeo_messages = []


def get_binance_position_usd_value(dup_counter):
    position_usd = (3 if Config.IS_DUP_PARTITION_ENABLED else 1) * Config.BINANCE_POSITION_USD_VALUE
    position_usd = (Config.DUP_PARTITION[dup_counter] if Config.IS_DUP_PARTITION_ENABLED else 1) * position_usd
    return round(position_usd, 2)


# returns previous cumulative loss caused by dup
def get_partitioned_previous_cumulative_dup_loss_percentage(dup_counter, profit_exit_type):
    partitioned_cumulative_dup_counter = 0

    ABOVE_DUP_VALUE = 1
    ABOVE_ENTRY_BELOW_D_UP_VALUE = 2
    ENTRY_PRICE_OR_BELOW_VALUE = 3

    profit_exit_type_value = profit_exit_type.value
    if profit_exit_type_value == ABOVE_DUP_VALUE or profit_exit_type_value == ABOVE_ENTRY_BELOW_D_UP_VALUE:
        if dup_counter == 0:
            partitioned_cumulative_dup_counter = 0  # no losses
        elif dup_counter == 1:
            partitioned_cumulative_dup_counter = 0  # no losses
        elif dup_counter == 2:
            partitioned_cumulative_dup_counter = Config.DUP_PARTITION[1]
        elif dup_counter == 3:
            partitioned_cumulative_dup_counter = (Config.DUP_PARTITION[1] + Config.DUP_PARTITION[2])
        elif dup_counter == 4:
            partitioned_cumulative_dup_counter = (
                    Config.DUP_PARTITION[1] + Config.DUP_PARTITION[2] + Config.DUP_PARTITION[3])
        elif dup_counter == 5:
            partitioned_cumulative_dup_counter = (
                    Config.DUP_PARTITION[1] + Config.DUP_PARTITION[2] + Config.DUP_PARTITION[3] +
                    Config.DUP_PARTITION[4])
        else:
            print("Error: romeo_util: dup_counter > dup_max : dup_counter=" + str(
                dup_counter) + ", profit_exit_type_value=" + str(profit_exit_type_value))
    else:
        # ENTRY_PRICE_OR_BELOW
        if dup_counter == 0:
            partitioned_cumulative_dup_counter = 0
        elif dup_counter == 1:
            partitioned_cumulative_dup_counter = Config.DUP_PARTITION[1]
        elif dup_counter == 2:
            partitioned_cumulative_dup_counter = (Config.DUP_PARTITION[1] + Config.DUP_PARTITION[2])
        elif dup_counter == 3:
            partitioned_cumulative_dup_counter = (
                    Config.DUP_PARTITION[1] + Config.DUP_PARTITION[2] + Config.DUP_PARTITION[3])
        elif dup_counter == 4:
            partitioned_cumulative_dup_counter = (
                    Config.DUP_PARTITION[1] + Config.DUP_PARTITION[2] + Config.DUP_PARTITION[3] +
                    Config.DUP_PARTITION[4])
        elif dup_counter == 5:
            partitioned_cumulative_dup_counter = (
                    Config.DUP_PARTITION[1] + Config.DUP_PARTITION[2] + Config.DUP_PARTITION[3] +
                    Config.DUP_PARTITION[4] + Config.DUP_PARTITION[5])
        else:
            print("Error: romeo_util: dup_counter > dup_max : dup_counter=" + str(
                dup_counter) + ", profit_exit_type_value=" + str(profit_exit_type_value))

    partitioned_previous_cumulative_dup_loss_percentage = partitioned_cumulative_dup_counter * Config.ROMEO_D_UP_PERCENTAGE

    print("get_partitioned_previous_cumulative_dup_loss_percentage : dup_counter=" + str(
        dup_counter) + ", profit_exit_type_value=" + str(
        profit_exit_type_value) + ", partitioned_cumulative_dup_counter=" + str(
        partitioned_cumulative_dup_counter) + ", partitioned_previous_cumulative_dup_loss_percentage=" + str(
        partitioned_previous_cumulative_dup_loss_percentage))

    return partitioned_previous_cumulative_dup_loss_percentage


# def stop_bot(reason):
#     stop_bot_command = "python3 " + Config.EXECUTION_PATH + "/stop_bot.py " + "prod" + " " + \
#                        Config.BRAIN + " " + reason.replace(": ", ":").replace(" ", "#"). \
#                            replace("(", "").replace(")", "")
#     result_log = subprocess.Popen([stop_bot_command],
#                                   stdout=subprocess.PIPE,
#                                   stderr=subprocess.PIPE, shell=True, executable='/bin/bash')
# 
#     out, err = result_log.communicate()
#     out_put = out.decode('latin-1')

def get_duration_string(start_timestamp):
    duration_sec = time() - start_timestamp
    if duration_sec < Config.SECONDS_IN_MINUTE:
        return str(round(duration_sec)) + " sec"
    elif duration_sec < Config.SECONDS_IN_HOUR:
        return str(duration_sec // Config.SECONDS_IN_MINUTE) + " min " + \
               str(duration_sec % Config.SECONDS_IN_MINUTE) + " sec"
    elif duration_sec < Config.SECONDS_IN_DAY:
        return str(duration_sec // Config.SECONDS_IN_HOUR) + " hours " + \
               str(duration_sec % Config.SECONDS_IN_HOUR // Config.SECONDS_IN_MINUTE) + " min " + \
               str(duration_sec % Config.SECONDS_IN_HOUR % Config.SECONDS_IN_MINUTE) + " sec"
    else:
        return str(duration_sec // Config.SECONDS_IN_DAY) + " day " \
            if duration_sec // Config.SECONDS_IN_DAY == 1 else \
            str(duration_sec // Config.SECONDS_IN_DAY) + " days " + \
            str(duration_sec % Config.SECONDS_IN_DAY // Config.SECONDS_IN_HOUR) + " hours " + \
            str(duration_sec % Config.SECONDS_IN_DAY % Config.SECONDS_IN_HOUR // Config.SECONDS_IN_MINUTE) + \
            " min " + str(duration_sec % Config.SECONDS_IN_DAY % Config.SECONDS_IN_HOUR %
                          Config.SECONDS_IN_MINUTE) + " sec"


def get_duration_minutes(start_timestamp):
    duration_sec = time() - start_timestamp
    return round(duration_sec / 60)