import os
from execution.config import Config


# returns cumulative_profit (float)
def append_to_cumulative_profit_file(file_path, profit_float):
    existing_profit = "0"

    if not os.path.exists(file_path):
        with open(file_path, 'w+') as file:
            file.write(str(profit_float))
        file.close()
        return float(existing_profit)

    with open(file_path, 'r') as read_file:
        existing_profit = read_file.read()
    read_file.close()

    cumulative_profit = float(existing_profit) + profit_float
    cumulative_profit = round(cumulative_profit, 2)

    with open(file_path, 'w') as write_file:
        write_file.write(str(cumulative_profit))
    write_file.close()
    return cumulative_profit


def set_initial_account_balance_binance(initial_account_balance):
    file_path = Config.INITIAL_ACCOUNT_BALANCE_BINANCE_FILE_PATH
    if not os.path.exists(file_path):
        print("set_initial_account_balance_binance: error - initial account balance file not found")
        return

    is_file_empty = False
    with open(file_path, 'r') as read_file:
        existing_value = read_file.read()
        is_file_empty = existing_value == ""
    read_file.close()

    print("set_initial_account_balance_binance: is_file_empty=" + str(is_file_empty) + ", initial_account_balance=" + str(initial_account_balance))

    if is_file_empty:
        with open(file_path, 'w') as write_file:
            write_file.write(str(initial_account_balance))
        write_file.close()


def get_initial_account_balance_binance():
    initial_account_balance = 0.0

    file_path = Config.INITIAL_ACCOUNT_BALANCE_BINANCE_FILE_PATH
    if not os.path.exists(file_path):
        print("get_initial_account_balance_binance: error - initial account balance file not found")
        return initial_account_balance

    with open(file_path, 'r') as read_file:
        initial_account_balance = float(read_file.read())
    read_file.close()

    return initial_account_balance
