import requests
from binance.client import Client
from binance.enums import *
from execution.broker.broker import Broker
from execution.config import Config
from execution.binance_util import get_binance_api_key, get_binance_api_secret, get_timestamp_before_sec, get_binance_position_usd_value

# todo dup-partition
class Binance_Spot_Broker(Broker):
    client = Client(get_binance_api_key(), get_binance_api_secret(), testnet=Config.BINANCE_TESTNET_MODE)
    # Example 0.271 LTC
    initial_position_coin_amount = 0.0
    partitioned_position_coin_amount = 0.0
    quantity_precision = 0
    price_precision = 0
    opened_long_position_coin_amount = 0.0
    notifier = None
    is_notify_enabled = False
    open_long_order_id = 0

    def __init__(self, notifier):
        super().__init__(notifier)
        self.notifier = notifier
        self.is_notify_enabled = False
        self.is_test_mode = notifier.is_test_mode
        self.__set_position_coin_amount()

    def __set_position_coin_amount(self):
        raw_position_coin_amount = self.__convert_usd_to_coin(get_binance_position_usd_value())
        self.quantity_precision = self.__get_quantity_precision()
        self.price_precision = self.__get_price_precision()

        self.initial_position_coin_amount = round(raw_position_coin_amount, self.quantity_precision)

        if self.initial_position_coin_amount == 0:
            self.initial_position_coin_amount = (raw_position_coin_amount * 10 ** self.quantity_precision) + 1
            self.initial_position_coin_amount = self.initial_position_coin_amount / 10 ** self.quantity_precision
            self.initial_position_coin_amount = round(self.initial_position_coin_amount, self.quantity_precision)

            if self.initial_position_coin_amount >= 1:
                usd_value = self.__convert_coin_to_usd(self.initial_position_coin_amount)
                if usd_value > get_binance_position_usd_value():
                    self.initial_position_coin_amount = round(raw_position_coin_amount, 2)

        print(
            "binance_spot_broker: set_position_coin_amount: raw_position_coin_amount=" + str(raw_position_coin_amount) +
            ", initial_position_coin_amount=" + str(self.initial_position_coin_amount) +
            ", quantity_precision=" + str(self.quantity_precision))

    def __notify(self, action, leverage, order_result):
        if self.is_notify_enabled:
            self.notifier.send_broker_message(action, self.initial_position_coin_amount, leverage, order_result,
                                              self.get_account_balance_usdt())

    def open_long(self, stop_order_price, dup_counter, force_market_order=False):
        # todo fix : stop-market order
        # todo  : use dup_counter: IS_DUP_PARTITION_ENABLED 
        print("Binance_Spot_Broker: open_long: before precision: stop_order_price=" + str(
            stop_order_price) + ", price_precision=" + str(self.price_precision))
        stop_order_price = round(stop_order_price, self.price_precision)
        current_price = round(self.get_current_price(), self.price_precision)
        print("Binance_Spot_Broker: open_long: dry_mode " + str(self.is_test_mode) + " initial_position_coin_amount = " + str(
            self.initial_position_coin_amount) + " " + Config.COIN + ", stop_order_price=" + str(
            stop_order_price) + ", current_price=" + str(current_price) + ", force_market_order=" +
              str(force_market_order))
        order = None
        result_str = ""
        if self.is_test_mode:
            try:
                if force_market_order or not Config.IS_LIMIT_STOP_ORDER_ENABLED:
                    order = self.client.create_test_order(side=SIDE_BUY, symbol=Config.COIN + Config.STABLE_COIN,
                                                          quantity=self.initial_position_coin_amount, type=ORDER_TYPE_MARKET)
                else:
                    order = self.client.create_test_order(side=SIDE_BUY, symbol=Config.COIN + Config.STABLE_COIN,
                                                          quantity=self.initial_position_coin_amount,
                                                          type=ORDER_TYPE_STOP_LOSS_LIMIT,
                                                          timeInForce=TIME_IN_FORCE_GTC, price=current_price,
                                                          stopPrice=stop_order_price,
                                                          trailingDelta=Config.BINANCE_SPOT_TRAILING_DELTA_VALUE)

                result_str = str(order)
                print(result_str)
            except Exception as e:
                print("Binance_Spot_Broker: open_long: an exception occurred - {}".format(e))
                result_str = str(e)
        else:
            try:
                if force_market_order or not Config.IS_LIMIT_STOP_ORDER_ENABLED:
                    order = self.client.create_order(side=SIDE_BUY, symbol=Config.COIN + Config.STABLE_COIN,
                                                     quantity=self.initial_position_coin_amount, type=ORDER_TYPE_MARKET)
                    self.opened_long_position_coin_amount = float(order['origQty'])
                else:
                    order = self.client.create_order(side=SIDE_BUY, symbol=Config.COIN + Config.STABLE_COIN,
                                                     quantity=self.initial_position_coin_amount,
                                                     type=ORDER_TYPE_STOP_LOSS_LIMIT,
                                                     timeInForce=TIME_IN_FORCE_GTC, price=current_price,
                                                     stopPrice=stop_order_price,
                                                     trailingDelta=Config.BINANCE_SPOT_TRAILING_DELTA_VALUE)

                result_str = str(order)
                print(result_str)
            except Exception as e:
                print("Binance_Spot_Broker: open_long: an exception occurred - {}".format(e))
                result_str = str(e)

        # self.open_long_order_id = order['orderId']
        self.__notify("BINANCE_SPOT_ORDER: OPEN_LONG ", "", result_str)

    def close_long(self, limit_order_price, force_market_order=False, force_refresh_coin_amount=False):  # ignore
        print("Binance_Spot_Broker: close_long: before precision: limit_order_price=" + str(
            limit_order_price) + ", price_precision=" + str(self.price_precision))
        if force_refresh_coin_amount:
            self.__set_position_coin_amount()
        limit_order_price = round(limit_order_price, self.price_precision)
        print(
            "Binance_Spot_Broker: close_long: dry_mode " + str(self.is_test_mode) + " initial_position_coin_amount = " + str(
                self.initial_position_coin_amount) + " " + Config.COIN + ", limit_order_price=" + str(
                limit_order_price) + ", force_market_order=" + str(
                force_market_order) + ", force_refresh_coin_amount=" + str(force_refresh_coin_amount))
        order = None
        result_str = ""
        if self.is_test_mode:
            try:
                if force_market_order or not Config.IS_LIMIT_STOP_ORDER_ENABLED:
                    order = self.client.create_test_order(side=SIDE_SELL, symbol=Config.COIN + Config.STABLE_COIN,
                                                          type=ORDER_TYPE_MARKET,
                                                          quantity=self.initial_position_coin_amount)
                else:
                    order = self.client.create_test_order(side=SIDE_SELL, symbol=Config.COIN + Config.STABLE_COIN,
                                                          quantity=self.initial_position_coin_amount,
                                                          timeInForce=TIME_IN_FORCE_GTC,
                                                          type=ORDER_TYPE_LIMIT, price=limit_order_price)
                result_str = str(order)
                print(result_str)
            except Exception as e:
                print("Binance_Spot_Broker: close_long: an exception occurred - {}".format(e))
                result_str = str(e)
        else:
            try:
                if force_market_order or not Config.IS_LIMIT_STOP_ORDER_ENABLED:
                    order = self.client.create_order(side=SIDE_SELL, symbol=Config.COIN + Config.STABLE_COIN,
                                                     type=ORDER_TYPE_MARKET,
                                                     quantity=self.opened_long_position_coin_amount)
                else:
                    order = self.client.create_order(side=SIDE_SELL, symbol=Config.COIN + Config.STABLE_COIN,
                                                     quantity=self.initial_position_coin_amount,
                                                     timeInForce=TIME_IN_FORCE_GTC,
                                                     type=ORDER_TYPE_LIMIT, price=limit_order_price)

                result_str = str(order)
                print(result_str)
            except Exception as e:
                print("Binance_Spot_Broker: close_long: an exception occurred - {}".format(e))
                result_str = str(e)

        self.__notify("BINANCE_SPOT_ORDER: CLOSE_LONG ", "", result_str)


    def open_short(self, limit_order_price, dup_counter, force_market_order=False):
        print("binance_broker: open_short: before precision: limit_order_price=" + str(
            limit_order_price) + ", price_precision=" + str(self.price_precision))
        limit_order_price = round(limit_order_price, self.price_precision)
        print(
            "binance_broker: open_short: dry_mode " + str(self.is_test_mode) + " position_coin_amount = " + str(
                self.position_coin_amount) + " " + Config.COIN + ", limit_order_price=" + str(
                limit_order_price) + ", force_market_order=" + str(force_market_order))
        leverage = self.client.futures_change_leverage(symbol=Config.COIN + Config.STABLE_COIN,
                                                       leverage=int(Config.BINANCE_LEVERAGE_VALUE))
        print("binance_broker: open_short: leverage = " + str(leverage))
        order = None
        result_str = ""
        if self.is_test_mode:
            try:
                if force_market_order or not Config.IS_LIMIT_ORDER_ENABLED:
                    order = self.client.create_test_order(side=SIDE_SELL, symbol=Config.COIN + Config.STABLE_COIN,
                                                          quantity=self.position_coin_amount, type=ORDER_TYPE_MARKET)
                else:
                    order = self.client.create_test_order(side=SIDE_SELL, symbol=Config.COIN + Config.STABLE_COIN,
                                                          quantity=self.position_coin_amount,
                                                          type=FUTURE_ORDER_TYPE_LIMIT,
                                                          timeInForce=TIME_IN_FORCE_GTC,
                                                          price=limit_order_price)
                result_str = str(order)
                print(result_str)
            except Exception as e:
                print("binance_broker: open_short: an exception occurred - {}".format(e))
                result_str = str(e)
        else:
            try:
                if force_market_order or not Config.IS_LIMIT_ORDER_ENABLED:
                    order = self.client.futures_create_order(side=SIDE_SELL, symbol=Config.COIN + Config.STABLE_COIN,
                                                             quantity=self.position_coin_amount, type=ORDER_TYPE_MARKET,
                                                             positionSide=Config.BINANCE_SHORT)
                else:
                    order = self.client.futures_create_order(side=SIDE_SELL, symbol=Config.COIN + Config.STABLE_COIN,
                                                             quantity=self.position_coin_amount,
                                                             positionSide=Config.BINANCE_SHORT,
                                                             type=FUTURE_ORDER_TYPE_LIMIT,
                                                             timeInForce=TIME_IN_FORCE_GTC,
                                                             price=limit_order_price
                                                             )
                self.opened_short_position_coin_amount = float(order['origQty'])
                result_str = str(order)
                print(result_str)
            except Exception as e:
                print("binance_broker: open_short: an exception occurred - {}".format(e))
                result_str = str(e)

        self.open_short_order_id = order['orderId']
        self.__notify("BINANCE_ORDER: OPEN_SHORT ", leverage['leverage'], result_str)

    def close_short(self, limit_order_price, force_market_order=False, force_refresh_coin_amount=False):  # ignore
        print("binance_broker: close_short: before precision: limit_order_price=" + str(
            limit_order_price) + ", price_precision=" + str(self.price_precision))
        if force_refresh_coin_amount:
            self.__set_position_coin_amount()
        limit_order_price = round(limit_order_price, self.price_precision)
        print(
            "binance_broker: close_short: dry_mode " + str(self.is_test_mode) + " position_coin_amount = " + str(
                self.position_coin_amount) + " " + Config.COIN + ", limit_order_price=" + str(
                limit_order_price) + ", force_market_order=" + str(
                force_market_order) + ", force_refresh_coin_amount=" + str(force_refresh_coin_amount))
        leverage = self.client.futures_change_leverage(symbol=Config.COIN + Config.STABLE_COIN,
                                                       leverage=int(Config.BINANCE_LEVERAGE_VALUE))
        print("binance_broker: close_short: leverage = " + str(leverage))
        order = None
        result_str = ""
        if self.is_test_mode:
            try:
                if force_market_order or not Config.IS_LIMIT_ORDER_ENABLED:
                    order = self.client.create_test_order(side=SIDE_BUY, symbol=Config.COIN + Config.STABLE_COIN,
                                                          type=ORDER_TYPE_MARKET,
                                                          quantity=self.position_coin_amount)
                else:
                    order = self.client.create_test_order(side=SIDE_BUY, symbol=Config.COIN + Config.STABLE_COIN,
                                                          type=FUTURE_ORDER_TYPE_LIMIT, timeInForce=TIME_IN_FORCE_GTC,
                                                          price=limit_order_price,
                                                          quantity=self.position_coin_amount)
                result_str = str(order)
                print(result_str)
            except Exception as e:
                print("binance_broker: close_short: an exception occurred - {}".format(e))
                result_str = str(e)
        else:
            try:
                if force_market_order or not Config.IS_LIMIT_ORDER_ENABLED:
                    order = self.client.futures_create_order(side=SIDE_BUY, symbol=Config.COIN + Config.STABLE_COIN,
                                                             positionSide=Config.BINANCE_SHORT, type=ORDER_TYPE_MARKET,
                                                             quantity=self.opened_short_position_coin_amount)
                else:
                    order = self.client.futures_create_order(side=SIDE_BUY, symbol=Config.COIN + Config.STABLE_COIN,
                                                             positionSide=Config.BINANCE_SHORT,
                                                             quantity=self.opened_short_position_coin_amount,
                                                             type=FUTURE_ORDER_TYPE_LIMIT,
                                                             timeInForce=TIME_IN_FORCE_GTC,
                                                             price=limit_order_price
                                                             )
                result_str = str(order)
                print(result_str)
            except Exception as e:
                print("binance_broker: close_short: an exception occurred - {}".format(e))
                result_str = str(e)

        self.__notify("BINANCE_ORDER: CLOSE_SHORT ", leverage['leverage'], result_str)

    def get_current_price(self):
        response = requests.get(Config.BINANCE_PRICE_API_URL + Config.COIN + Config.STABLE_COIN).json()
        return float(response['price'])

    def get_current_ask_price(self):
        return float(self.client.get_order_book(symbol=Config.COIN + Config.STABLE_COIN)['asks'][0][0])

    def get_current_bid_price(self):
        return float(self.client.get_order_book(symbol=Config.COIN + Config.STABLE_COIN)['bids'][0][0])

    # returns in USD
    def __convert_coin_to_usd(self, coin_amount):
        return coin_amount * self.get_current_price()

    # returns in coin Eg. ADA
    def __convert_usd_to_coin(self, usd_amount):
        return usd_amount / self.get_current_price()

    def get_account_balance_usdt(self):
        try:
            response = self.client.get_account()
            balance_usdt = 0.0
            for value in response['balances']:
                if value['asset'] == Config.STABLE_COIN:
                    balance_usdt = round(float(value['free']), 2)
            return balance_usdt
        except Exception as e:
            print("Binance_Spot_Broker: get_account_balance_usdt: an exception occurred - {}".format(e))

    # if a price in an order is has more precision than this number, then error #2 down there will be thrown
    def __get_quantity_precision(self):
        coin_information = self.client.futures_exchange_info()
        for x in coin_information['symbols']:
            if x['symbol'] == Config.COIN + Config.STABLE_COIN:
                return x['quantityPrecision']

    def __get_price_precision(self):
        coin_information = self.client.futures_exchange_info()
        for x in coin_information['symbols']:
            if x['symbol'] == Config.COIN + Config.STABLE_COIN:
                return x['pricePrecision']

    def get_all_open_positions_by_coin(self):
        print("Binance_Spot_Broker: get_all_open_positions_by_coin")
        return self.client.get_my_trades(symbol=Config.COIN + Config.STABLE_COIN, recvWindow=60000)

    def get_all_used_symbol(self):
        exchange_info = self.client.get_exchange_info()
        symbols = []
        for exchange in exchange_info['symbols']:
            symbols.append(exchange['symbol'])
        return symbols

    def get_all_open_positions(self):
        print("Binance_Spot_Broker: get_all_open_positions")
        symbols = self.get_all_used_symbol()
        all_trades = []
        for symbol in symbols:
            all_trades.append(self.client.get_my_trades(symbol=symbol, recvWindow=60000))
        return all_trades
    
    def close_all_open_positions(self):
        print("Binance_Spot_Broker: close_all_open_positions")
        open_positions = self.get_all_open_positions()
        if len(open_positions) > 0:
            for position in open_positions:
                if position['isBuyer']:
                    Config.COIN = position['symbol'].split(Config.STABLE_COIN)[0]
                    self.opened_long_position_coin_amount = float(position['qty'])
                    self.open_short(0, force_market_order=True)
        else:
            print("Binance_Spot_Broker: close_all_open_positions: no open positions")

        if Config.IS_SCHEDULE_ORDER:
            self.cancel_all_scheduled_positions()

    def cancel_all_scheduled_positions(self):
        self.client.cancel_order(symbol=Config.COIN + Config.STABLE_COIN,
                                 orderId=self.open_long_order_id,
                                 timestamp=True)

    # def get_scheduled_short_order_list_count_by_coin(self):
    #     result = self.client.get_open_orders(symbol=Config.COIN + Config.STABLE_COIN, recvWindow=60000)
    #     list_of_short_orders = []
    #     for results in result:
    #         if results["side"] == Config.SELL:
    #             list_of_short_orders.append(results)
    #     print("Binance_Spot_Broker: get_scheduled_short_order_list_count_by_coin: list_of_short_orders=" + str(
    #         list_of_short_orders))
    #     return len(list_of_short_orders)

    def get_scheduled_buy_order_list_count_by_coin(self):
        buy_orders = []
        open_positions = self.get_all_open_positions()
        if len(open_positions) > 0:
            for position in open_positions:
                if position['isBuyer']:
                    buy_orders.append(position)
        print("Binance_Spot_Broker: get_scheduled_buy_order_list_count_by_coin: buy_orders=" + str(
            buy_orders))
        return len(buy_orders)

    def get_scheduled_sell_order_list_count_by_coin(self):
        sell_orders = []
        open_positions = self.get_all_open_positions()
        if len(open_positions) > 0:
            for position in open_positions:
                if not position['isBuyer']:
                    sell_orders.append(position)
        print("Binance_Spot_Broker: get_scheduled_sell_order_list_count_by_coin: buy_orders=" + str(
            sell_orders))
        return len(sell_orders)

    # returns List of the recent trades made in the past 5 seconds.
    # returns None, if there were no trades made in the past 5 seconds.
    def get_recent_trade_history_list_by_coin(self):
        # recent_trades = self.client.get_my_trades(symbol=Config.COIN + Config.STABLE_COIN , startTime=get_timestamp_before_sec(100*60))
        recent_trades = self.client.get_recent_trades(symbol=Config.COIN + Config.STABLE_COIN, limit=1000)
        print("******* get_timestamp_before_sec(10)=" + str(get_timestamp_before_sec(10)))
        # 23047983870,  23047983869, ---- last id of 500 was : id=758143988

        print("******* recent_trades.size=" + str(len(recent_trades)))
        filtered_trades = []

        # print("===== recent_trades="+str((recent_trades)))
        # for trade in recent_trades:
        #     print("---- id="+str(trade['id']) + " price="+str(trade['price']) + ' timestamp='+str(trade['time']) + " humanReadable="+ datetime.datetime.fromtimestamp(trade['time']/1000).strftime('%Y-%m-%d %H:%M:%S'))

        # for trade in recent_trades:
        #     order_id = trade['orderId']
        #     if order_id == self.open_long_order_id or order_id == self.open_short_order_id:
        #         filtered_trades.append(trade)
        #         print("******* price=" + trade['price'])

        print("******* recent_trades.size=" + str(len(recent_trades)))
        print("******* filtered_trades.size=" + str(len(filtered_trades)))

        print("===== filtered_trades=" + str((filtered_trades)))

        # for trade in recent_trades:
        #     if int(trade['time']) > get_timestamp_before_sec(10):
        #         filtered_trades.append(trade)
        # print("******* filtered_trades="+str(filtered_trades))
        #
        return filtered_trades if filtered_trades else None
        # return recent_trades if recent_trades else None

        # [{'symbol': 'BTCUSDT', 'id': 1146581793, 'orderId': 8273511664, 'orderListId': -1, 'price': '61933.43000000',
        #   'qty': '0.00606000', 'quoteQty': '375.31658580', 'commission': '0.37531659', 'commissionAsset': 'USDT',
        #   'time': 1637030164487, 'isBuyer': False, 'isMaker': False, 'isBestMatch': True}]
    def get_remaining_account_balance_usdt(self):
        """
        TODO -- get remaining account balance after long positions are opened
        """
        return 1000
# Binance errors:
# 1. APIError(code=-1013): Filter failure: MIN_NOTIONAL - this means the position is less than 10 USD
# 2. APIError(code=-1111): Precision is over the maximum defined for this asset. [Todo]
# 3. APIError(code=-2022): ReduceOnly Order is rejected. - when closeLong is called before openLong

# APIError(code=-2015): Invalid API-key, IP, or permissions for action. - this can occur if TestNet=True and TestMode=True

# ADA: precision_max=0 : price is $1 BINANCE_ORDER
# SOL: precision_max=0 : price is $140 BINANCE_ORDER ___
# XLM : precision_max=0 : price is $0.25 BINANCE_ORDER ___
# ETH :precision_max=3: price is $3,101 BINANCE_ORDER ___
# LTC :precision_max=3: price is $130 BINANCE_ORDER ___
# BTC :precision_max=3: price is $41,726 BINANCE_ORDER ___
