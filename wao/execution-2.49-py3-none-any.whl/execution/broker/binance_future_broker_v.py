import requests
from binance.client import Client
from binance.enums import *
from execution.broker.broker import Broker
from execution.broker.binance_future_broker import Binance_Future_Broker
from execution.config import Config
import datetime
import ast
import time


class Binance_Future_Broker_V(Binance_Future_Broker):
    # romeo-v
    quantity_coin = 0
    ratio_coin_amount = 0

    def open_long(self, stop_order_price, dup_counter, force_market_order=False,dup_ratio_percentage=1):
        # todo  : dup partition
        self.price_precision = self._Binance_Future_Broker__get_price_precision()
        print("binance_future_broker_v: open_long: before precision: stop_order_price=" + str(
            stop_order_price) + ", price_precision=" + str(self.price_precision))

        stop_order_price = round(stop_order_price, self.price_precision)
        current_price = round(self.get_current_price(), self.price_precision)
        print("binance_future_broker_v: open_long: dry_mode " + str(self.is_test_mode) + " initial_position_coin_amount = " + str(
            self.initial_position_coin_amount) + " " + Config.COIN + ", stop_order_price=" + str(
            stop_order_price) + ", Current_price=" + str(current_price) + ", force_market_order=" +
              str(force_market_order))

        leverage = self.client.futures_change_leverage(symbol=Config.COIN + Config.STABLE_COIN,
                                                       leverage=int(Config.BINANCE_LEVERAGE_VALUE))
        print("binance_future_broker_v: open_long: leverage = " + str(leverage))
        order = None
        result_str = ""
        self.ratio_coin_amount = round(self.initial_position_coin_amount * dup_ratio_percentage)
        if self.is_test_mode:
            try:
                if force_market_order or not Config.IS_LIMIT_STOP_ORDER_ENABLED:
                    order = self.client.create_test_order(side=SIDE_BUY, symbol=Config.COIN + Config.STABLE_COIN,
                                                          quantity=self.ratio_coin_amount, type=ORDER_TYPE_MARKET)
                else:
                    # in future while we use the dry run it simulates the spot trading therefore we need to add
                    # trailingDelta
                    order = self.client.create_test_order(side=SIDE_BUY, symbol=Config.COIN + Config.STABLE_COIN,
                                                          quantity=self.ratio_coin_amount,
                                                          type=ORDER_TYPE_STOP_LOSS_LIMIT,
                                                          timeInForce=TIME_IN_FORCE_GTC, 
                                                          price=current_price,
                                                          stopPrice=stop_order_price,
                                                          trailingDelta=Config.BINANCE_SPOT_TRAILING_DELTA_VALUE)

                result_str = str(order)
                print(result_str)
                self.quantity_coin = float(result_str[0]['origQty'])
            except Exception as e:
                print("binance_future_broker_v: open_long: an exception occurred - {}".format(e))
                result_str = str(e)
        else:
            try:
                if force_market_order or not Config.IS_LIMIT_STOP_ORDER_ENABLED:
                    order = self.client.futures_create_order(side=SIDE_BUY, symbol=Config.COIN + Config.STABLE_COIN,
                                                             quantity=self.ratio_coin_amount, # self.initial_position_coin_amount
                                                             type=ORDER_TYPE_MARKET,
                                                             positionSide=Config.BINANCE_LONG)
                else:
                    order = self.client.futures_create_order(side=SIDE_BUY, symbol=Config.COIN + Config.STABLE_COIN,
                                                             positionSide=Config.BINANCE_LONG,
                                                             quantity=self.ratio_coin_amount, #self.initial_position_coin_amount
                                                             type=FUTURE_ORDER_TYPE_STOP_MARKET,
                                                             timeInForce=TIME_IN_FORCE_GTC,
                                                             price=current_price,
                                                             StopPrice=stop_order_price,
                                                             newOrderRespType = "RESULT")

                self.opened_long_position_coin_amount = float(order['origQty'])
                self.open_long_order_id = order['orderId']
                result_str = str(order)
                result_str = result_str.strip("][")
                result_str = ast.literal_eval(result_str)
                self.quantity_coin = float(result_str['origQty'])
            except Exception as e:
                print("binance_future_broker_v: open_long: an exception occurred - {}".format(e))
                result_str = str(e)


        self._Binance_Future_Broker__notify("BINANCE_ORDER: OPEN_LONG ", leverage['leverage'], result_str)

    def close_long(self, stop_order_price, force_market_order=False, force_refresh_coin_amount=False,dup_ratio_percentage=1):
        print("binance_future_broker_v: close_long: before precision: stop_order_price=" + str(
            stop_order_price) + ", price_precision=" + str(self.price_precision))
        if force_refresh_coin_amount:
            self._Binance_Future_Broker__set_position_coin_amount()

        stop_order_price = round(stop_order_price, self.price_precision)
        print(
            "binance_future_broker_v: close_long: dry_mode " + str(self.is_test_mode) + " initial_position_coin_amount = " + str(
                self.initial_position_coin_amount) + " " + Config.COIN + ", stop_order_price=" + str(
                stop_order_price) + ", force_market_order=" + str(
                force_market_order) + ", force_refresh_coin_amount=" + str(force_refresh_coin_amount))

        self.client.futures_change_leverage(symbol=Config.COIN + Config.STABLE_COIN,
                                            leverage=int(Config.BINANCE_LEVERAGE_VALUE))
        leverage = self.client.futures_change_leverage(symbol=Config.COIN + Config.STABLE_COIN,
                                                       leverage=int(Config.BINANCE_LEVERAGE_VALUE))
        print("binance_future_broker_v: close_long: leverage = " + str(leverage))

        order = None
        result_str = ""
        self.ratio_coin_amount = round(self.initial_position_coin_amount * dup_ratio_percentage)
        symbol = Config.COIN + Config.STABLE_COIN
        if self.is_test_mode:
            try:
                if force_market_order or not Config.IS_LIMIT_STOP_ORDER_ENABLED:
                    order = self.client.create_test_order(side=SIDE_SELL, symbol=Config.COIN + Config.STABLE_COIN,
                                                          type=ORDER_TYPE_MARKET,
                                                          quantity=self.ratio_coin_amount,
                                                          newOrderRespType = "RESULT")
                else:
                    order = self.client.create_test_order(side=SIDE_SELL, symbol=Config.COIN + Config.STABLE_COIN,
                                                          quantity=self.ratio_coin_amount,
                                                          type=FUTURE_ORDER_TYPE_LIMIT, 
                                                          timeInForce=TIME_IN_FORCE_GTC,
                                                          newOrderRespType = "RESULT",
                                                          price=stop_order_price
                                                          )
                result_str = str(order)
                print(result_str)
                result_str = result_str.strip("][") 
                result_str = ast.literal_eval(result_str)
                self.quantity_coin -= float(result_str['origQty'])
            except Exception as e:
                print("binance_future_broker_v: close_long: an exception occurred - {}".format(e))
                result_str = str(e)
        else:
            try:
                if force_market_order or not Config.IS_LIMIT_STOP_ORDER_ENABLED:
                    order = self.client.futures_create_order(side=SIDE_SELL, symbol=Config.COIN + Config.STABLE_COIN,
                                                             type=ORDER_TYPE_MARKET, positionSide=Config.BINANCE_LONG,
                                                             quantity=self.ratio_coin_amount, #self.opened_long_position_coin_amount
                                                             newOrderRespType = "RESULT")
                else:
                    order = self.client.futures_create_order(side=SIDE_SELL, symbol=Config.COIN + Config.STABLE_COIN,
                                                             positionSide=Config.BINANCE_LONG,
                                                             quantity=self.ratio_coin_amount, #self.opened_long_position_coin_amount
                                                             type=FUTURE_ORDER_TYPE_STOP_MARKET,
                                                             timeInForce=TIME_IN_FORCE_GTC,
                                                             newOrderRespType = "RESULT",
                                                             stopPrice=stop_order_price)

                result_str = str(order)
                print(result_str)
                result_str = result_str.strip("][")
                result_str = ast.literal_eval(result_str)
                self.quantity_coin -= float(result_str['origQty'])


            except Exception as e:
                print("binance_future_broker_v: close_long: an exception occurred - {}".format(e))
                result_str = str(e)

        self._Binance_Future_Broker__notify("BINANCE_ORDER: CLOSE_LONG ", leverage['leverage'], result_str)


# Binance errors:
# 1. APIError(code=-1013): Filter failure: MIN_NOTIONAL - this means the position is less than 10 USD
# 2. APIError(code=-1111): Precision is over the maximum defined for this asset. [Todo]
# 3. APIError(code=-2022): ReduceOnly Order is rejected. - when closeLong is called before openLong
# 4. APIError(code=-2019): Margin is insufficient.

# APIError(code=-2015): Invalid API-key, IP, or permissions for action. - this can occur if TestNet=True and TestMode=True

# ADA: precision_max=0 : price is $1 BINANCE_ORDER
# SOL: precision_max=0 : price is $140 BINANCE_ORDER ___
# XLM : precision_max=0 : price is $0.25 BINANCE_ORDER ___
# ETH :precision_max=3: price is $3,101 BINANCE_ORDER ___
# LTC :precision_max=3: price is $130 BINANCE_ORDER ___
# BTC :precision_max=3: price is $41,726 BINANCE_ORDER ___

