from execution.config import Config
from execution.broker.binance_future_broker_v import Binance_Future_Broker_V
from execution.broker.binance_spot_broker import Binance_Spot_Broker
from execution.notifier_v import NotifierV
import threading

Config.COIN = "ADA"
if Config.IS_BINANCE_FUTURE_MODE:
    broker = Binance_Future_Broker_V(NotifierV(True))
else:
    broker = Binance_Spot_Broker(NotifierV(True))

current_price = broker.get_current_price()
print("********* current_price="+str(current_price))
bid_price = broker.get_current_bid_price()
print("********* bid_price="+str(bid_price))
ask_price = broker.get_current_ask_price()
print("********* ask_price="+str(ask_price))


# threading.Thread(target=broker.open_long, args=(0, True)).start()
# broker.open_long(0, force_market_order=True)

# d_up_price = bid_price + (bid_price * Config.ROMEO_D_UP_PERCENTAGE / 100.0)
# broker.close_long(d_up_price)


# broker.get_recent_trade_history_list_by_coin()

# print(str(broker.convert_coin_to_usd(test_coin_amount)) + " USD")
# broker.open_long()
# broker.close_long()

# broker.open_short(0, force_market_order=True)




# broker.open_long(ask_price, force_market_order=True)
# broker.open_short(bid_price, force_market_order=True)



# limit_price = current_price * ( (1 - (0.1/100) ))
# broker.close_short(limit_price)

# print("------------  count="+str(broker.get_scheduled_long_order_list_count_by_coin()))
# print("------------  list="+str(broker.get_scheduled_long_order_list_count_by_coin()))

print("------------  account balance="+str(broker.get_account_balance_usdt()))
print("------------  remaining account balance="+str(broker.get_remaining_account_balance_usdt()))
# print("------------  trade_history.size="+str(len(broker.get_recent_trade_history_list_by_coin())))
# print("------------  trade_history="+str((broker.get_recent_trade_history_list_by_coin())))



# broker.close_short()