import time
from threading import Thread
from binance.client import Client

from execution.config import Config
from execution.keys import Keys


class Back_Test_V3_Live_Market_Data_Worker_Thread(Thread):
    is_thread_stopped = False
    execution_id = None

    def __init__(self, execution_id):
        super(Back_Test_V3_Live_Market_Data_Worker_Thread, self).__init__()
        self.execution_id = execution_id

    def stop(self):
        self.is_thread_stopped = True

    def run(self):
        is_trigger_started = False
        client = Client(Keys.BINANCE_API_KEY, Keys.BINANCE_API_SECRET)
        historical_data = client.get_historical_klines(Config.COIN + Config.STABLE_COIN, Config.BACKTEST_TIME_FRAME,
                                                       Config.BACKTEST_LIVE_DATA_START_DATE,
                                                       Config.BACKTEST_LIVE_DATA_END_DATE)
        index = 0
        if Config.DEBUG_LOG_ENABLED:
            print("Back_Test_V3_Live_Market_Data_Worker_Thread: lines.size=" + str(len(historical_data)))
        for candlestick in historical_data:
            candlestick[0] = int(candlestick[0] / 1000)
            candlestick[1] = float(candlestick[1])

            if self.is_thread_stopped:
                break

            line_time_stamp = int(candlestick[0])
            if not is_trigger_started and line_time_stamp >= Config.BACKTEST_BUY_SIGNAL_TIMESTAMP:
                is_trigger_started = True
            else:
                if Config.DEBUG_LOG_ENABLED:
                    print(
                        "Back_Test_V3_Live_Market_Data_Worker_Thread: waiting for SIGNAL_TIMESTAMP to arrive...  BACKTEST_BUY_SIGNAL_TIMESTAMP=" + str(
                            Config.BACKTEST_BUY_SIGNAL_TIMESTAMP) +", BACKTEST_SELL_SIGNAL_TIMESTAMP="+ str(Config.BACKTEST_SELL_SIGNAL_TIMESTAMP) + ", line_time_stamp=" + str(line_time_stamp))

            if is_trigger_started:
                index += 1

                if Config.DEBUG_LOG_ENABLED:
                    print(
                        "Back_Test_V3_Live_Market_Data_Worker_Thread: PROGRESS="
                        + str(round(float((index * 100) / len(historical_data)), 2)) + " %"
                        + ", execution_id=" + self.execution_id
                        + ", coin=" + Config.COIN)

                price_string = str(candlestick[1])

                Config.bus.emit(Config.EVENT_BUS_BACKTEST_MARKET_DATA_KEY, price_string)
                time.sleep(Config.BACKTEST_THROTTLE_SECOND)

                if Config.BACKTEST_SELL_SIGNAL_TIMESTAMP is not None and line_time_stamp >= Config.BACKTEST_SELL_SIGNAL_TIMESTAMP:
                    Config.bus.emit(Config.EVENT_BUS_BACKTEST_SELL_SIGNAL_KEY, price_string)
                    self.stop()
