from event_bus import EventBus


class Config:
    bus = EventBus()

    VERSION = "2.49"

    IS_OBS_LSTM_ENABLED = True

    COIN = "ADA"
    STABLE_COIN = "USDT"
    IS_LSTM_DATASOURCE_MARKET_DATA = False
    BRAIN = "Freq_Strategy002"

    ROMEO_D_UP_PERCENTAGE = 0.1 # comes from the strategy
    ROMEO_PT_PERCENTAGE = 2
    ROMEO_D_UP_MAX = 5
    ROMEO_VERBOSE_MODE = True
    # if false, notify only start() and finish()
    ROMEO_SS_TIMEOUT_HOURS = 1 # comes from the strategy

    IS_BACKTEST = False
    IS_BACKTEST_V3_ENABLED = False
    IS_SS_ENABLED = True

    BACKTEST_MONTH_INDEX = 1 # february
    BACKTEST_BUY_SIGNAL_TIMESTAMP = None  # 12344315
    BACKTEST_SELL_SIGNAL_TIMESTAMP = None  # 12344315
    BACKTEST_THROTTLE_SECOND = 0
    BACKTEST_YEAR = 2021
    ROOT = "/root"
    WORKSPACE = "/workspace2" if IS_BACKTEST else "/workspace"
    EXECUTION_PATH = ROOT + WORKSPACE + "/execution"
    FREQTRADE_PATH = ROOT + WORKSPACE + "/freqtrade"
    BACKTEST_EXECUTION_FINISHED_FILE_PATH = EXECUTION_PATH + "/_backtest_execution_finished.txt"
    BACKTEST_DOWNLOAD_DATA_DIRECTORY = FREQTRADE_PATH + "/_backtest_data/"
    BACKTEST_SIGNAL_LIST_PICKLE_FILE_PATH = FREQTRADE_PATH + "/_backtest_list.pickle"
    _429_DIRECTORY = FREQTRADE_PATH + "/_429_directory/"
    _ROMEO_MESSAGE_CSV_FILE_DIRECTORY = EXECUTION_PATH + "/_romeo_message_csv_file_directory/"
    CUMULATIVE_PROFIT_FILE_PATH = FREQTRADE_PATH + "/_cumulative_profit.txt"
    CUMULATIVE_PROFIT_BINANCE_FILE_PATH = FREQTRADE_PATH + "/_cumulative_profit_binance.txt"
    INITIAL_ACCOUNT_BALANCE_BINANCE_FILE_PATH = FREQTRADE_PATH + "/_initial_account_balance_binance.txt"
    BACKTEST_TIME_FRAME = "1m"
    BACKTEST_TIMEFRAME_READABLE = "minute" if BACKTEST_TIME_FRAME == '1m' else "hour"
    BACKTEST_LIVE_DATA_START_DATE = "1 Jan, 2021"
    BACKTEST_LIVE_DATA_END_DATE = "1 Feb, 2021"

    CSV_FORMAT = '.csv'
    MONTH_LIST = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    WEEKDAY_LIST = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]

    EVENT_BUS_BINANCE_RECONNECT = "EVENT_BUS_BINANCE_RECONNECT"
    EVENT_BUS_MARKET_DATA_KEY = "EVENT_BUS_MARKET_DATA_KEY"
    EVENT_BUS_BACKTEST_MARKET_DATA_KEY = "EVENT_BUS_BACKTEST_MARKET_DATA_KEY"
    EVENT_BUS_BACKTEST_SELL_SIGNAL_KEY = "EVENT_BUS_BACKTEST_SELL_SIGNAL_KEY"
    EVENT_BUS_EXECUTION_SELF_COMPLETE = "EVENT_BUS_EXECUTION_SELF_COMPLETE"

    IS_BINANCE_FUTURE_MODE = True  # if False spot mode
    BINANCE_TESTNET_MODE = False
    BINANCE_TRADE_STREAM_ENABLED = True
    BINANCE_TLD = "us"
    BINANCE_PRICE_API_URL = "https://api.binance.com/api/v3/ticker/price?symbol="
    BINANCE_SPOT_DATA_PREFIX = "@trade" if BINANCE_TRADE_STREAM_ENABLED else "@kline_"
    BINANCE_FUTURE_DATA_PREFIX = "@markPrice" if BINANCE_TRADE_STREAM_ENABLED else "@kline_"
    BINANCE_TIME_RANGE = "" if BINANCE_TRADE_STREAM_ENABLED else "1h"
    BINANCE_SHORT = "SHORT"
    BINANCE_LONG = "LONG"
    SELL = "SELL"
    BUY = "BUY"
    BINANCE_FUTURES_API_URL = "https://fapi.binance.com/"
    BINANCE_POSITION_USD_VALUE = 15
    BINANCE_LEVERAGE_VALUE = 2
    BINANCE_SPOT_TRAILING_DELTA_VALUE = 100  # these are called BIPS used in spot 1 = 0.01%, 10 = 0.1%, 100 = 1%,
    # 1000 = 10%

    SECONDS_IN_MINUTE = 60
    SECONDS_IN_HOUR = 3600
    SECONDS_IN_DAY = SECONDS_IN_HOUR * 24

    IS_PERFORMANCE_MONITOR_ENABLED = True
    PERFORMANCE_MONITOR_MAX_LOSS_PERCENTAGE_ACCOUNT = 5
    HEALTH_MONITOR_BELOW_ENTRY_PRICE_PERCENTAGE = 0.2
    HEALTH_MONITOR_ABOVE_DUP_PERCENTAGE = 0.2

    MODE_TEST = "test"
    MODE_PROD = "prod"

    ENABLE_429_SOLUTION = False

    NOTIFIER_ENABLED = not IS_BACKTEST
    IS_PARALLEL_EXECUTION = True
    DEBUG_LOG_ENABLED = True
    TELEGRAM_LOG_ENABLED = True
    IS_ROMEO_MESSAGE_TO_GOOGLE_SHEET_ENABLED = True

    IS_SHELL_BROKER_ENABLED = IS_BACKTEST
    
    # if false, the broker uses market order by default
    IS_LIMIT_STOP_ORDER_ENABLED = True

    IS_SCHEDULE_ORDER = True
    SIMULATE_LIMIT_ORDER_CALLBACK_DELAY_SEC = 1.0

    IS_DUP_PARTITION_ENABLED = True
    DUP_PARTITION = {0: 0.00,
                     1: 1.00,
                     2: 0.75,
                     3: 0.50,
                     4: 0.33,
                     5: 0.33,
                     6: 1.00
                     }
    '''
    First DUP CROSSED = 100% OL 
    Second DUP CROSSED = 75% OL 
    Third DUP CROSSED = 50% OL 
    Fourth DUP CROSSED = 33% OL 
    Fifth DUP CROSSED = 33% OL 
    '''
    
    # Romeo V setting
    IS_ROMEO_V_ENABLED = False
    DUP_RATIO_CONDITION_VALUE_1 = 0.15
    DUP_RATIO_CONDITION_VALUE_2 = 0.2
    DUP_RATIO_CONDITION_VALUE_3 = 0.3
    DUP_RATIO_CONDITION_VALUE_4 = 0.4
    DUP_RATIO_CONDITION_VALUE_5 = 0.5    
    
