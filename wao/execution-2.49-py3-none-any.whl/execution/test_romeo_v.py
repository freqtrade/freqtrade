
from execution.romeo_v import RomeoV


RomeoV.instance(False).start()

# def start():
#     Romeo.instance()

# if __name__ == '__main__':
#     delay = 2  # in seconds
#     Timer(delay, start, []).start()

