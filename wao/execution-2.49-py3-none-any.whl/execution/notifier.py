import requests
import os
from execution.config import Config
from execution.keys import Keys
from execution._429_file_util import delete_429_file, write_to_429_file


def get_partitioner(dup_counter):
    return Config.DUP_PARTITION[dup_counter]


def get_binance_position_usd_value(dup_counter):
    position_usd = (3 if Config.IS_DUP_PARTITION_ENABLED else 1) * Config.BINANCE_POSITION_USD_VALUE
    position_usd = (get_partitioner(dup_counter) if Config.IS_DUP_PARTITION_ENABLED else 1) * position_usd
    return round(position_usd, 2)


class Notifier:
    BOLD = "*"
    NL = "\n"
    TELEGRAM_RESPONSE_429 = "<Response [429]>"

    def __init__(self, is_test_mode):
        self.is_test_mode = is_test_mode
        self.machine_name = os.uname().nodename

    def send_stop_bot_message(self, reason):
        text = "[STOP_BOT_SCRIPT] Bot Stopped! Positions Closed! Reason: " + reason
        print("Notifier: send_stop_bot_message: " + str(text))
        self.post_request(text)

    def send_romeo_message(self, action, coin_amount, entry_price,
                           d_up_crossed_counter, execution_id,
                           profit=None, duration=None, romeo_exit_price_string=None):
        print("Notifier: send_romeo_message: action=" + str(action))
        text = self.BOLD + "Action: " + self.BOLD + self.BOLD + action + self.BOLD + self.NL \
               + self.BOLD + "Machine: " + self.BOLD + str(self.machine_name) + self.NL \
               + self.BOLD + "Version: " + self.BOLD + Config.VERSION + self.NL \
               + self.BOLD + "Execution ID: " + self.BOLD + str(execution_id) + self.NL \
               + self.BOLD + "Brain: " + self.BOLD + Config.BRAIN.replace("_", " ") + self.NL \
               + self.BOLD + "Test mode: " + self.BOLD + str(self.is_test_mode) + ", Bnc-test-net: " + str(
            Config.BINANCE_TESTNET_MODE) + self.NL \
               + self.BOLD + "Entry price: " + self.BOLD + str(entry_price) + " USD" + self.NL \
               + self.BOLD + "D_UP: " + self.BOLD + str(Config.ROMEO_D_UP_PERCENTAGE) + " (" + str(
            get_d_up_price(entry_price)) + " USD)" + self.NL \
               + self.BOLD + "D_UP crossed counter: " + self.BOLD + str(d_up_crossed_counter) + self.NL \
               + self.BOLD + "D_UP MAX: " + self.BOLD + str(Config.ROMEO_D_UP_MAX) + self.NL \
               + self.BOLD + "Duration: " + self.BOLD + str(duration) + self.NL \
               + self.BOLD + "Profit: " + self.BOLD + str(profit) + self.NL \
               + self.BOLD + "ExitPriceType: " + self.BOLD + str(romeo_exit_price_string).replace("_", " ") + self.NL \
               + (self.BOLD + "Position: " + self.BOLD + str(coin_amount) + " " + Config.COIN + " (" + str(
            get_binance_position_usd_value(d_up_crossed_counter)) + " USD)")
        self.post_request(text, True)

    def send_broker_message(self, action, coin_amount, leverage, order_result, account_balance):
        print("Notifier: send_broker_message: action=" + str(action))
        text = self.BOLD + "Action: " + self.BOLD + self.BOLD + action + self.BOLD + self.NL \
               + self.BOLD + "Machine: " + self.BOLD + str(self.machine_name) + self.NL \
               + self.BOLD + "Coin amount: " + self.BOLD + str(coin_amount) + " " + Config.COIN + self.NL \
               + self.BOLD + "Leverage: " + self.BOLD + str(leverage) + "X" + self.NL \
               + self.BOLD + "Order result: " + self.BOLD + order_result + self.NL \
               + self.BOLD + "Account balance: " + self.BOLD + str(account_balance) + " USD"

        self.post_request(text)

    def get_telegram_bot_api_token(self):
        if self.is_test_mode:
            if Config.IS_BACKTEST:
                return Keys.NOTIFIER_TELEGRAM_BOT_API_TOKEN_BACKTEST
            elif Config.BRAIN == "lstm":
                return Keys.NOTIFIER_TELEGRAM_BOT_API_TOKEN_LSTM_TEST
            else:
                return Keys.NOTIFIER_TELEGRAM_BOT_API_TOKEN[Config.BRAIN]
        else:
            if Config.BRAIN == "lstm":
                return Keys.NOTIFIER_TELEGRAM_BOT_API_TOKEN_LSTM_PROD
            else:
                return Keys.NOTIFIER_TELEGRAM_BOT_API_TOKEN[Config.BRAIN]

    def get_telegram_channel_id(self):
        if self.is_test_mode:
            if Config.IS_BACKTEST:
                return Keys.NOTIFIER_TELEGRAM_CHANNEL_ID_BACKTEST
            elif Config.BRAIN == "lstm":
                return Keys.NOTIFIER_TELEGRAM_CHANNEL_ID_LSTM_TEST
            else:
                return Keys.NOTIFIER_TELEGRAM_CHANNEL_ID[Config.BRAIN]
        else:
            if Config.BRAIN == "lstm":
                return Keys.NOTIFIER_TELEGRAM_CHANNEL_ID_LSTM_PROD
            else:
                return Keys.NOTIFIER_TELEGRAM_CHANNEL_ID[Config.BRAIN]

    def post_request(self, text, is_from_romeo=False):
        text.replace("#", " ")
        if Config.TELEGRAM_LOG_ENABLED:
            print("post_request: " + text + " ---------------------")

        if Config.NOTIFIER_ENABLED:
            result = requests.post('https://api.telegram.org/bot' + self.get_telegram_bot_api_token() +
                                   '/sendMessage?chat_id=' + self.get_telegram_channel_id() + '&text=' +
                                   text + '&parse_mode=Markdown')
            print(str(result))

            if str(result) == self.TELEGRAM_RESPONSE_429 and is_from_romeo and Config.ENABLE_429_SOLUTION:
                delete_429_file(text)
                write_to_429_file(text)


# don't put in util: circular dependency
def get_d_up_price(entry_price):
    return "None" if entry_price is None else entry_price + (entry_price * Config.ROMEO_D_UP_PERCENTAGE / 100.0)
