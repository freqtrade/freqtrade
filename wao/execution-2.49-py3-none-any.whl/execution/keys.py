from execution.config import Config


class Keys:
    NOTIFIER_SENDER_EMAIL_ADDRESS = "romeotrading4@gmail.com"
    NOTIFIER_SENDER_EMAIL_PASSWORD = "tradingml2021!"
    NOTIFIER_RECEIVER_EMAIL_ADDRESS = "romeotrading4@gmail.com"

    NOTIFIER_TELEGRAM_CHANNEL_ID = {"Freq_bbrsi_scalp": "-1001775030826", "Freq_Cluc6werk": "-1001634175825",
                                    "Freq_bb_15m": "-1001778572733", "Freq_bb_15m_ada_btc": "-1001548905146",
                                    "Freq_Cluc5werk": "-1001589644762",
                                    "Freq_bbrsi_scalp_ada_btc": "-1001774581377"}
    NOTIFIER_TELEGRAM_BOT_API_TOKEN = {"Freq_bbrsi_scalp": "5070131175:AAGb550TFr5bkDvyDspemewFDi-qIn2zR10",
                                       "Freq_Cluc6werk": "5488447798:AAE_y8Tma1Cngvs4d_j7usWS2xbZXKMcp0M",
                                       "Freq_bb_15m": "5589026849:AAFmRLRCzQD7ZKNfbJNXG6qdJRfrivmaQWg",
                                       "Freq_bb_15m_ada_btc": "5594003155:AAE1bAOkfz1XGxpW0i1EKS7un7FbREOaWSA",
                                       "Freq_Cluc5werk": "5306690065:AAGhhr5sokAw2h-cElN3Gslnv_7zEX3Z6Ec",
                                       "Freq_bbrsi_scalp_ada_btc": "5563436943:AAHJiDgZSVkzKjRCZ34bCsPrXaCqf9cL2eo"
                                       }

    NOTIFIER_TELEGRAM_CHANNEL_ID_LSTM_PROD = ""
    NOTIFIER_TELEGRAM_BOT_API_TOKEN_LSTM_PROD = ""

    NOTIFIER_TELEGRAM_CHANNEL_ID_LSTM_TEST = "-1001699754402" if Config.IS_OBS_LSTM_ENABLED else "-1001728426477"
    NOTIFIER_TELEGRAM_BOT_API_TOKEN_LSTM_TEST = "5394462263:AAH2WlR53ko8Kdoodun_d0jS1hy6Pv-WaVA" if Config.IS_OBS_LSTM_ENABLED else "5394514318:AAHfvp8rK9K8gNLL6hthINgbtpYCM4r8iZw"

    NOTIFIER_TELEGRAM_CHANNEL_ID_BACKTEST = "-1001658942980"
    NOTIFIER_TELEGRAM_BOT_API_TOKEN_BACKTEST = "5203777569:AAE5mIwFuqSH_n1E8sIWQE-adWGT_8EbTOM"

    NOTIFIER_TELEGRAM_BOT_API_TOKEN_429 = "5144801192:AAG9InpYtl9mx0R9_yZsOyFbaI4A1OXqMKY"

    NOTIFIER_TELEGRAM_CHANNEL_ID_BBRSI_TEST = "-1001617020043"
    NOTIFIER_TELEGRAM_BOT_API_TOKEN_BBRSI_TEST = "5013262741:AAElm9Nmhil4VmnXdbyv6DI8G9GxIcF9tvg"

    NOTIFIER_TELEGRAM_CHANNEL_ID_ROMEO_V = "-1001769643418"
    NOTIFIER_TELEGRAM_BOT_API_TOKEN_ROMEO_V = "5506603020:AAGA0dEkd8dioYcXdIc9qnRHMM3FtnPFi0Q"

    WORKSHEET_TITLE = {"Freq_bbrsi_scalp": "BBRSI LTC XMR XLM", "Freq_Cluc6werk": "Cluc6Werk",
                       "Freq_bb_15m": "BB 15m", "Freq_bb_15m_ada_btc": "ADA BB 15m",
                       "Freq_Cluc5werk": "Cluc5Werk", "Freq_bbrsi_scalp_ada_btc": "BBRSI ADA BTC"}

    BINANCE_API_KEY = "Ped2xNLEBnPQikPp4Uwm13PJKG5eM4O0DIuPoFk0hwfbZeiJrJR0E4WLSLn1CHtx"
    BINANCE_API_SECRET = "qTB10rwARboDgx5eWTngN3nfwKHYi3vkMbosG0ueRIg2LyYU99fctVxZWWIcf2ex"
    BINANCE_TESTNET_API_KEY = "f982f35520e22273ec2c2f2f28f8e9938d63ff5a3fa2b67f98e10f6c53c2edbb"
    BINANCE_TESTNET_API_SECRET = "94ea3d72287e4bab0c8ac4b77e84abbc678a36ef1b6859794253811c15d54b16"
