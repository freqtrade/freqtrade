import time

from execution.config import Config
from execution.util import perform_back_test_buy, perform_back_test_sell, clear_execution_state, is_execution_state_open, clear_cumulative_value
import pickle
import threading
from execution.backtest_signal import BacktestExecution
from execution.backtest_data_util import check_data_download

start_time = time.time()
clear_cumulative_value()
print("STEP [2]++++++++++++++++++++++++++++++++++++" + ", read_from_backtest_table")
backtest_signal_list = pickle.load(open(Config.BACKTEST_SIGNAL_LIST_PICKLE_FILE_PATH, 'rb'))
print("STEP [2]++++++++++++++++++++++++++++++++++++" + ", backtest_signal_list.size=" + str(len(backtest_signal_list)))
print(*backtest_signal_list)

# BacktestSignalList to BacktestExecutionList mapper
backtest_execution_list = []
backtest_execution = None

for backtest_signal in backtest_signal_list:

    if backtest_signal.type == "buy":
        if backtest_execution is None:
            backtest_execution = BacktestExecution(backtest_signal, None)
        else:
            backtest_execution.buy_signal = backtest_signal
            print('STEP [3]++++++++++++++++ backtest_execution is not None: replacing buy signal')

    if backtest_signal.type == "sell":
        if backtest_execution is None:
            print('STEP [3]++++++++++++++++ backtest_execution is None: ignoring sell signal')
        else:
            backtest_execution.sell_signal = backtest_signal

    if backtest_execution.is_ready():
        backtest_execution_list.append(backtest_execution)
        backtest_execution = None

print("STEP [4] ++++++" + ", backtest_execution_list.size=" + str(len(backtest_execution_list)))


def __buy_back_test(date_time, coin, brain, timeout_hours, dup):
    if Config.IS_PARALLEL_EXECUTION:
        threading.Thread(target=perform_back_test_buy,
                         args=(date_time, coin, brain, timeout_hours, dup)).start()
    else:
        perform_back_test_buy(date_time, coin, brain, timeout_hours, dup)


def __get_duration_string(start_time_stamp):
    duration_sec = time.time() - start_time_stamp
    if duration_sec < 60:
        return str(round(duration_sec)) + " sec"
    else:
        return str(round(duration_sec / 60)) + " min " + \
               str(round(duration_sec % 60)) + " sec"


index = 0
for back_test_execution in backtest_execution_list:
    print("STEP [5]+++++ executing back_test_execution: " + str(index + 1) + " of " + str(len(backtest_execution_list)))

    buy_signal = back_test_execution.buy_signal
    check_data_download(buy_signal.timestamp, buy_signal.coin)
    print("STEP [5]+++++ executing back_test_execution: buy_signal=" + str(buy_signal))
    __buy_back_test(buy_signal.timestamp, buy_signal.coin, buy_signal.brain, buy_signal.timeout_hours, buy_signal.dup)

    sell_signal = back_test_execution.sell_signal
    print("STEP [5]+++++ executing back_test_execution: sell_signal=" + str(sell_signal))
    perform_back_test_sell(sell_signal.timestamp)

    while is_execution_state_open():
        print("STEP [5] ++++++++ is_execution_state_open: True, waiting for execution to complete...")
        time.sleep(1)

    print("STEP [5] ++++++++++++++++++ is_execution_state_open: False, Execution Complete!!")

    clear_execution_state()
    index += 1

print("STEP [6] ++++++ Completed " + str(len(backtest_execution_list)) + " Executions in " + __get_duration_string(start_time) + " !")
