import os
import subprocess

from execution.config import Config


def check_data_download(date, coin):
    print("check_data_download: date=" + str(date) + " coin=" + coin)
    month_index = __get_month_from_date(date)
    year = __get_year_from_date(date)
    file_name = Config.BACKTEST_DOWNLOAD_DATA_DIRECTORY + coin + "_" + \
                Config.BACKTEST_TIMEFRAME_READABLE + "_" + Config.MONTH_LIST[month_index] + '_' + \
                str(year) + Config.CSV_FORMAT
    if not os.path.isfile(file_name):
        __trigger_backtest_download_data(coin, month_index, year)


def __trigger_backtest_download_data(coin, month_index, year):
    print("trigger_backtest_download_data:")
    download_data_trigger_command = "python3 month_data_download.py " + coin + " " + \
                                    str(month_index) + " " + str(year)
    result = subprocess.Popen([download_data_trigger_command],
                              stdout=subprocess.PIPE,
                              stderr=subprocess.PIPE, shell=True, executable='/bin/bash')
    out, err = result.communicate()
    out_put_string = out.decode('latin-1')
    print(out_put_string)


def __get_month_from_date(timestamp) -> int:
    month_index = int(str(timestamp).split()[0].split('-')[1]) - 1
    return month_index


def __get_year_from_date(timestamp) -> int:
    year = str(timestamp).split()[0].split('-')[0]
    return int(year)
