from threading import Thread

from execution.config import *
import json
import websocket
import sys
import traceback


class Binance_Market_Data_Worker_Thread(Thread):
    websocket = None

    def __init__(self, ):
        super(Binance_Market_Data_Worker_Thread, self).__init__()

    def stop(self):
        print('Binance_Market_Data_Worker: stop')
        self.websocket.close()

    def run(self):
        print('Binance_Market_Data_Worker: run: [start]')
        self.websocket = websocket.WebSocketApp(get_binance_web_socket_uri(), on_open=on_open, on_close=on_close,
                                                on_message=on_market_data, on_error=on_error)
        self.websocket.run_forever()


def get_binance_web_socket_uri():
    if Config.IS_BINANCE_FUTURE_MODE:
        return "wss://fstream.binance.com/ws/" + Config.COIN.lower() + Config.STABLE_COIN.lower() + Config.BINANCE_FUTURE_DATA_PREFIX + Config.BINANCE_TIME_RANGE
    else:
        return "wss://stream.binance.com:9443/ws/" + Config.COIN.lower() + Config.STABLE_COIN.lower() + Config.BINANCE_SPOT_DATA_PREFIX + Config.BINANCE_TIME_RANGE


def on_open(websocket):
    print('Binance_Market_Data_Worker: on_open: opened connection')


def on_error(websocket, exception):
    exception_str = str(exception)
    exception_str_lower = exception_str.lower()

    if "connection timed out" in exception_str_lower or "read timed out" in exception_str_lower or "internal error; unable to process your request" in exception_str_lower:
        print('Binance_Market_Data_Worker: reconnecting...')
        Config.bus.emit(Config.EVENT_BUS_BINANCE_RECONNECT, "reconnect")
        return

    print('Binance_Market_Data_Worker: on_error : error : exception=' + exception_str)
    ex_type, ex_value, ex_traceback = sys.exc_info()
    trace_back = traceback.extract_tb(ex_traceback)
    # Format stacktrace
    stack_trace = list()

    for trace in trace_back:
        stack_trace.append(
            "File : %s , Line : %d, Func.Name : %s, Message : %s" % (trace[0], trace[1], trace[2], trace[3]))

    print("Exception type : %s " % ex_type.__name__)
    print("Exception message : %s" % ex_value)
    print("Stack trace : %s" % stack_trace)


def on_close(websocket, close_status_code, close_msg):
    print('Binance_Market_Data_Worker: on_close: closed connection: close_status_code=' + str(
        close_status_code) + ', close_msg=' + str(close_msg))


def on_market_data(websocket, message):
    print('Binance_Market_Data_Worker: on_market_data: received message')
    json_message = json.loads(message)
    Config.bus.emit(Config.EVENT_BUS_MARKET_DATA_KEY, str(json_message))
