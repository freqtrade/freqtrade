import threading
from enum import Enum

from execution.broker.binance_spot_broker import Binance_Spot_Broker
from execution.broker.shell_broker import Shell_Broker
from execution.broker.binance_future_broker_v import Binance_Future_Broker_V

from execution.cumulative_profit_file_util import append_to_cumulative_profit_file, set_initial_account_balance_binance, \
    get_initial_account_balance_binance
from execution.market_data_worker_thread.back_test_market_data_worker_thread import Back_Test_Market_Data_Worker_Thread
from execution.market_data_worker_thread.back_test_v3_live_market_data_worker_thread import \
    Back_Test_V3_Live_Market_Data_Worker_Thread
from execution.market_data_worker_thread.binance_market_data_worker_thread import Binance_Market_Data_Worker_Thread
from execution.notifier_v import NotifierV
from execution.romeo_util import *
from time import time
from execution.romeo import Romeo, RomeoState, RomeoExitPriceType, _perform_romeo


def _perform_romeo(price):
    romeo = RomeoV.instance(RomeoV.is_test_mode)
    romeo.current_price = price

    romeo.init_broker()
    if Config.IS_SCHEDULE_ORDER:
        romeo.init_scheduled_order_count()
        
    if Config.DEBUG_LOG_ENABLED:
        print("Romeo: _perform_romeo: price=" + str(price) + " entry_price=" + str(
            romeo.entry_price) + " is_started=" + str(romeo.is_started) + " d_up_crossed_counter=" + str(
            romeo.d_up_crossed_counter) + ", execution_id=" + str(romeo.execution_id) + ", is_long_open=" + str(
            romeo.is_long_open))

    if romeo.is_started:

        if Config.DEBUG_LOG_ENABLED:
            print("Romeo: _perform_romeo: d_up=" + str(romeo.d_up_price) + " pt=" + str(
                romeo.pt_price) + " coin=" + Config.COIN + " brain=" + Config.BRAIN)

        romeo.prev_state = romeo.current_state
        romeo.current_state = romeo.get_current_state()

        if Config.DEBUG_LOG_ENABLED:
            print("Romeo: _perform_romeo: prev_state=" + str(romeo.prev_state) + " current_state=" + str(
                romeo.current_state))

        # Error Cases [START] - Health Monitor
        if not romeo.is_long_open and romeo.current_price > romeo.d_up_price * (
                1 + Config.HEALTH_MONITOR_ABOVE_DUP_PERCENTAGE):
            print(
                "Romeo: _perform_romeo: Error:  [not is_long_open AND current_price is above dup]. dup_price=" + str(
                    romeo.d_up_price) +
                " current_price=" + str(romeo.current_price))
            romeo.is_started = False 

        if romeo.d_up_crossed_counter > Config.ROMEO_D_UP_MAX:
            print("Romeo: _perform_romeo: an error occurred - dup counter is above dup max counter: "
                  "d_up_crossed_counter= " + str(romeo.d_up_crossed_counter) + "D_UP_MAX=" + str(
                Config.ROMEO_D_UP_MAX))
            romeo.is_started = False

        if romeo.current_price > romeo.d_up_price * (1 + Config.HEALTH_MONITOR_ABOVE_DUP_PERCENTAGE) and romeo.d_up_crossed_counter == 0:
            print( "Romeo: _perform_romeo: Error:  [current_price is above dup and romeo.d_up_crossed_counter == 0]")
            romeo.is_started = False

        open_long_positions = romeo.broker.get_all_open_positions_by_coin()
        entry_price_health_monitor_level = romeo.entry_price * (1 - Config.HEALTH_MONITOR_BELOW_ENTRY_PRICE_PERCENTAGE)
        if romeo.current_price < entry_price_health_monitor_level and romeo.is_long_open and open_long_positions:
            print("Romeo: _perform_romeo: Error: [ romeo.current_price < romeo.entry_price and romeo.is_long_open and open_long_positions]")
            romeo.is_started = False
        # Error Cases [END] - Health Monitor

        if not Config.IS_SCHEDULE_ORDER and (not romeo.is_long_open or romeo.is_long_partially_open) \
                and (romeo.prev_state == RomeoState.BELOW_ENTRY
                     or romeo.prev_state == RomeoState.ABOVE_ENTRY_BELOW_D_UP) \
                and (romeo.current_state == RomeoState.ABOVE_D_UP_BELOW_PT
                     or romeo.current_state == RomeoState.ABOVE_PT) \
                and (romeo.d_up_crossed_counter < Config.ROMEO_D_UP_MAX):  # yellow - d_up crossed
            romeo.on_dup_crossed_upwards_callback()

        if not Config.IS_SCHEDULE_ORDER and romeo.prev_state == RomeoState.ABOVE_D_UP_BELOW_PT \
                and romeo.current_state == RomeoState.ABOVE_PT \
                and not Config.IS_SS_ENABLED:  # green - PT reached
            romeo.perform_sell_signal(RomeoExitPriceType.PT)

        if not Config.IS_SCHEDULE_ORDER and (romeo.is_long_open or romeo.is_long_partially_open)\
                and romeo.d_up_crossed_counter > 0 \
                and (romeo.prev_state == RomeoState.ABOVE_PT
                     or romeo.prev_state == RomeoState.ABOVE_D_UP_BELOW_PT
                     or romeo.prev_state == RomeoState.ABOVE_ENTRY_BELOW_D_UP) \
                and romeo.current_state == RomeoState.BELOW_ENTRY:  # purple - entry_price crossed downwards
            romeo.on_entry_crossed_downwards_callback()

        if Config.IS_SS_ENABLED and get_duration_minutes(romeo.start_timestamp) > (
                Config.ROMEO_SS_TIMEOUT_HOURS * 60):
            print("Romeo: _perform_romeo: warning: timeout: sending ss")
            romeo.perform_sell_signal(RomeoExitPriceType.SS, is_timed_out=True)

        if romeo.is_started and Config.IS_SCHEDULE_ORDER:
            # give delay: binance_broker.get_scheduled_order returns Max retries exceeded error
            simulation_delay = time() - romeo.simulate_limit_order_timestamp

            print("Romeo: _perform_romeo: simulation_delay=" + str(
                simulation_delay) + ", SIMULATE_LIMIT_ORDER_CALLBACK_DELAY_SEC=" + str(
                Config.SIMULATE_LIMIT_ORDER_CALLBACK_DELAY_SEC))

            if simulation_delay > Config.SIMULATE_LIMIT_ORDER_CALLBACK_DELAY_SEC:
                romeo.simulate_limit_order_callback()
                romeo.simulate_limit_order_timestamp = time()


class RomeoV(Romeo):
    notifier = None
    # Romeo-V-long additions
    close_long_dup_ratio_percentage = 0
    open_long_dup_ratio_percentage = 0
    is_long_partially_open = False

    @classmethod
    def instance(cls, is_test_mode, force_new_instance=False):
        instance = super().instance(is_test_mode, force_new_instance)
        instance.notifier = NotifierV(is_test_mode)
        return instance


    def get_dup_ratio_percentage(self):
        dup_ratio_percentage = 0
        self.is_long_partially_open = True    
        if Config.ROMEO_D_UP_PERCENTAGE<=0.15:
            dup_ratio_percentage = 1
            self.is_long_partially_open = False
            self.is_long_open = True
        elif Config.DUP_RATIO_CONDITION_VALUE_1 < Config.ROMEO_D_UP_PERCENTAGE <= Config.DUP_RATIO_CONDITION_VALUE_2:
            dup_ratio_percentage = 0.9
        elif Config.DUP_RATIO_CONDITION_VALUE_2 < Config.ROMEO_D_UP_PERCENTAGE <= Config.DUP_RATIO_CONDITION_VALUE_3:
            dup_ratio_percentage = 0.8
        elif Config.DUP_RATIO_CONDITION_VALUE_3 < Config.ROMEO_D_UP_PERCENTAGE <= Config.DUP_RATIO_CONDITION_VALUE_4:
            dup_ratio_percentage = 0.7
        elif Config.DUP_RATIO_CONDITION_VALUE_4 < Config.ROMEO_D_UP_PERCENTAGE <= Config.DUP_RATIO_CONDITION_VALUE_5:
            dup_ratio_percentage = 0.6
        elif Config.ROMEO_D_UP_PERCENTAGE > Config.DUP_RATIO_CONDITION_VALUE_5:
            dup_ratio_percentage = 0.5
        return dup_ratio_percentage

    # This method is called from limit order callbacks as well
    # This is what romeo does when on_dup_crossed_upwards:
    def on_dup_crossed_upwards_callback(self):
        self.open_long_dup_ratio_percentage = self.get_dup_ratio_percentage()
        print("romeo: on_dup_crossed_upwards_callback : self.is_long_open = " + str(self.is_long_open)
              + " self.is_long_partially_open = " + str(self.is_long_partially_open))
        print("romeo: on_dup_crossed_upwards_callback: open_long_dup_ratio_percentage=" + str(
            self.open_long_dup_ratio_percentage) +
              " close_long_dup_ratio_percentage=" + str(self.close_long_dup_ratio_percentage))

        if Config.IS_SCHEDULE_ORDER:
            self.d_up_crossed_counter += 1
            # schedule CL at entry
            print("Romeo: on_dup_crossed_upwards_callback: SCHEDULE CL AT ENTRY")
            self.broker.close_long(self.entry_price)
        elif not self.is_long_open:
            self.broker.open_long(self.d_up_price, dup_ratio_percentage=self.open_long_dup_ratio_percentage)
            self.is_long_open = True
            self.d_up_crossed_counter += 1

        # sending romeo notifier message
        self.send_romeo_message_notify("ROMEO: UPWARDS: Price Crossing D_UP: OL")
        self.close_long_dup_ratio_percentage = self.open_long_dup_ratio_percentage # same positions opened must be closed when entry price is crossed.
        # Reset open_long_dup_ratio_percentage to ZERO
        self.open_long_dup_ratio_percentage = 0

    # This method is called from limit order callbacks as well
    # This is what romeo does when on_entry_crossed_downwards:
    def on_entry_crossed_downwards_callback(self):
        print("romeo: on_entry_crossed_downwards_callback: open_long_dup_ratio_percentage=" + str(
            self.open_long_dup_ratio_percentage) +
              " close_long_dup_ratio_percentage=" + str(self.close_long_dup_ratio_percentage))
        self.is_long_open = False
        if self.d_up_crossed_counter == Config.ROMEO_D_UP_MAX:
            self.notify(
                "ROMEO: DOWNWARDS: Price Crossing ENTRY_PRICE: D_UP_MAX reached " + str(
                    Config.ROMEO_D_UP_MAX) + ": FINISH (LOSS)")
            self.get_dup_ratio_percentage()
            self.finish(RomeoExitPriceType.ENTRY_PRICE)
            Config.bus.emit(Config.EVENT_BUS_EXECUTION_SELF_COMPLETE, Config.COIN)
        else:
            if Config.IS_SCHEDULE_ORDER:
                # schedule OL at d_up
                print("Romeo: on_entry_crossed_downwards_callback: SCHEDULE OL AT D_UP")
                self.broker.open_long(self.d_up_price)
            else:
                self.broker.close_long(self.entry_price,dup_ratio_percentage=self.close_long_dup_ratio_percentage)
            self.send_romeo_message_notify("ROMEO: DOWNWARDS: Price Crossing ENTRY_PRICE: CL (LOSS)")
            # self.is_long_open = False
            self.close_long_dup_ratio_percentage = 0 # Reset the value
        print("romeo: on_dup_crossed_upwards_callback : self.is_long_open = " + str(self.is_long_open)
        + " self.is_long_partially_open = "+str(self.is_long_partially_open))


    def init_broker(self):
        if self.broker is None:
            if Config.IS_SHELL_BROKER_ENABLED:
                self.broker = Shell_Broker(self.notifier)
            else:
                if Config.IS_BINANCE_FUTURE_MODE:
                    self.broker = Binance_Future_Broker_V(self.notifier)
                else:
                    self.broker = Binance_Spot_Broker(self.notifier)

    def finish(self, romeo_exit_price, is_timed_out=False):
        # CL
        if self.is_long_open or self.is_long_partially_open:
            self.close_long_dup_ratio_percentage = self.get_dup_ratio_percentage()
            self.broker.close_long(0, force_market_order=True,
                                   dup_ratio_percentage=self.close_long_dup_ratio_percentage)
            self.is_long_open = False
            self.is_long_partially_open = False

        super().finish(romeo_exit_price)


    @Config.bus.on(Config.EVENT_BUS_MARKET_DATA_KEY)
    def on_market_data(json_message_string):
        # if Config.DEBUG_LOG_ENABLED:
        # print("on_market_data: "+ json_message_string)
        # from random import random
        # price = random()
        price = get_price(json_message_string)
        _perform_romeo(price)

    @Config.bus.on(Config.EVENT_BUS_BACKTEST_MARKET_DATA_KEY)
    def on_back_test_market_data(price):
        _perform_romeo(float(price))

    @Config.bus.on(Config.EVENT_BUS_BACKTEST_SELL_SIGNAL_KEY)
    def on_back_test_sell_signal(price):
        romeo = RomeoV.instance(RomeoV.is_test_mode)
        romeo.back_test_sell_signal_exit_price = float(price)
        romeo.perform_sell_signal(RomeoExitPriceType.SS)

    def _perform_send_romeo_message_notify(self, action,
                        position_coin_amount,
                        duration=None, profit=None, force_notify=False, romeo_exit_price_string=None):
        if Config.ROMEO_VERBOSE_MODE or force_notify:
            self.notify_message_counter += 1
            self.notifier.send_romeo_message_v(action, position_coin_amount,
                                             self.entry_price,
                                             self.d_up_crossed_counter,
                                             str(self.execution_id) + "-" + str(self.notify_message_counter),
                                             duration=duration, profit=profit,
                                             romeo_exit_price_string=romeo_exit_price_string,
                                             open_long_percentage=self.open_long_dup_ratio_percentage,
                                             close_long_percentage=self.close_long_dup_ratio_percentage,
                                             quantity_coin=self.broker.quantity_coin)
