import firebase_admin
from firebase_admin import credentials
from firebase_admin import db
from execution.config import Config


class Firebase:

    def __init__(self):
        # Fetch the service account key JSON file contents
        # cred = credentials.Certificate('wao-firebase-key.json')
        cred = credentials.Certificate(Config.KEYS_PATH + '/wao-firebase-key.json')

        # Initialize the app with a custom auth variable, limiting the server's access
        firebase_admin.initialize_app(cred, {
            'databaseURL': 'https://wao-firebase-project-default-rtdb.firebaseio.com/',
        })

    def get_ip_whitelist(self):
        # The app only has access as defined in the Security Rules
        ref = db.reference('/ip_whitelist')
        print(ref.get())
        return []  # return list of ips
