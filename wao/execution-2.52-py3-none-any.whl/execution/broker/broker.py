class Broker:
    # Example 0.271 LTC
    initial_position_coin_amount = 0.0
    partitioned_position_coin_amount = 0.0
    price_precision = 0

    def __init__(self, notifier):
        pass

    def open_long(self, stop_order_price, dup_counter, force_market_order=False):
        pass

    def close_long(self, limit_order_price, force_market_order=False, force_refresh_coin_amount=False):
        pass
    
    def open_short(self, limit_order_price, dup_counter, force_market_order=False):
        pass

    def close_short(self, stop_order_price, force_market_order=False, force_refresh_coin_amount=False):
        pass

    def get_current_price(self):
        pass

    def get_current_ask_price(self):
        pass

    def get_current_bid_price(self):
        pass

    def get_account_balance_usdt(self):
        pass

    def get_all_open_positions(self):
        pass    
    
    def get_all_open_positions_by_coin(self):
        pass

    def close_all_open_positions(self):
        pass

    def cancel_all_scheduled_positions(self):
        pass

    def cancel_all_scheduled_positions_by_coin(self):
        pass

    def get_scheduled_buy_order_list_count_by_coin(self):
        pass

    def get_scheduled_sell_order_list_count_by_coin(self):
        pass

    def get_recent_trade_history_list_by_coin(self):
        pass
    
    def get_remaining_account_balance_usdt(self):
        pass
